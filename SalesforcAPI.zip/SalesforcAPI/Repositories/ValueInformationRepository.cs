﻿// Repositories/ValueInformationRepository.cs
using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SalesforcAPI.Interfaces;
using SalesforcAPI.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace SalesforcAPI.Repositories
{
    public class ValueInformationRepository : IValueInformationRepository
    {
        private readonly string _connectionString;
        private readonly ILogger<ValueInformationRepository> _logger;
        private readonly IMemoryCache _cache;
        private readonly IRequestSoap _requestSoap;                          // ✅ SOAP service injected
        private readonly TimeSpan _cacheDuration = TimeSpan.FromMinutes(5);

        private const string SoapUrl = "http://10.154.5.45:8093/TXLife/services/TXLife";

        public ValueInformationRepository(
            IConfiguration configuration,
            ILogger<ValueInformationRepository> logger,
            IMemoryCache cache,
            IRequestSoap requestSoap)                                        // ✅ injected
        {
            _connectionString = configuration.GetConnectionString("NDIBOARD33")
                ?? throw new ArgumentNullException(nameof(configuration), "Connection string NDIBOARD33 not found.");
            _logger = logger;
            _cache = cache;
            _requestSoap = requestSoap;
        }

        public async Task<ValueInformationResponse?> GetValueInformationAsync(string policyId)
        {
            if (string.IsNullOrWhiteSpace(policyId))
                throw new ArgumentException("PolicyId cannot be null or empty", nameof(policyId));

            var sw = Stopwatch.StartNew();
            var cacheKey = $"ValueInfo_{policyId}";

            if (_cache.TryGetValue<ValueInformationResponse>(cacheKey, out var cachedResult))
            {
                _logger.LogInformation("Cache HIT PolicyId={PolicyId} Time={Elapsed}ms",
                    policyId, sw.ElapsedMilliseconds);
                return cachedResult;
            }

            // ── 1. SQL ────────────────────────────────────────────────────────
            using var connection = new SqlConnection(_connectionString);
            await connection.OpenAsync();

            var policyExists = await CheckPolicyExistsAsync(connection, policyId);
            if (!policyExists)
            {
                _logger.LogWarning("Policy NOT FOUND PolicyId={PolicyId}", policyId);
                return null;
            }

            ValueInformationResponse valueInfo;

            var sql = BuildOptimizedQuery();
            using (var multi = await connection.QueryMultipleAsync(sql,
                new { PolicyId = policyId }, commandTimeout: 60))
            {
                var sqlResult = await multi.ReadFirstOrDefaultAsync<ValueInformationResponse>();
                valueInfo = sqlResult ?? new ValueInformationResponse { PolicyId = policyId };
                valueInfo.PolicyId ??= policyId;

                var fundInfo = await multi.ReadAsync<FundInformation>();
                valueInfo.FundInformation = fundInfo?.ToList() ?? new List<FundInformation>();
            }

            // ── 2. SOAP: InquiryFundValues ───────────────────────────────────
            try
            {
                var xmlFV = BuildInquiryFundValuesRequest(policyId);
                var responseFV = _requestSoap.PostSOAPRequestAsync(SoapUrl, xmlFV.ToString());
                var formattedFV = XDocument.Parse(responseFV).ToString();

                XmlDocument docFV = new();
                docFV.LoadXml(formattedFV);
                XmlNamespaceManager nsFV = new(docFV.NameTable);
                nsFV.AddNamespace("soap", "http://schemas.xmlsoap.org/soap/envelope/");
                nsFV.AddNamespace("ns", "http://ACORD.org/Standards/Life/2");

                var nodesFV = docFV.SelectNodes("//ns:InquiryFundValuesData", nsFV);
                if (nodesFV != null)
                {
                    foreach (XmlNode node in nodesFV)
                    {
                        valueInfo.MCVNetBaseCaseValue =
                            ParseDecimal(node.SelectSingleNode("ns:MirDvMcvAcumAmt", nsFV)?.InnerText);
                        valueInfo.SurrenderCharge =
                            ParseDecimal(node.SelectSingleNode("ns:MirDvSurrChrgAnt", nsFV)?.InnerText);
                        valueInfo.CashSurrenderValue =
                            ParseDecimal(node.SelectSingleNode("ns:MirDvPolCsvAmt", nsFV)?.InnerText);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "SOAP InquiryFundValues failed for PolicyId={PolicyId}", policyId);
                // Non-fatal: continue with SQL data; SOAP fields remain 0
            }

            // ── 3. SOAP: InquiryPolicyValues ─────────────────────────────────
            try
            {
                var xmlPV = BuildInquiryPolicyValuesRequest(policyId);
                var responsePV = _requestSoap.PostSOAPRequestAsync(SoapUrl, xmlPV.ToString());
                var formattedPV = XDocument.Parse(responsePV).ToString();

                XmlDocument docPV = new();
                docPV.LoadXml(formattedPV);
                XmlNamespaceManager nsPV = new(docPV.NameTable);
                nsPV.AddNamespace("soap", "http://schemas.xmlsoap.org/soap/envelope/");
                nsPV.AddNamespace("ns", "http://ACORD.org/Standards/Life/2");

                var nodesPV = docPV.SelectNodes("//ns:InquiryPolicyValuesData", nsPV);
                if (nodesPV != null)
                {
                    foreach (XmlNode node in nodesPV)
                    {
                        valueInfo.PaidupAdditionsCaseValue =
                            ParseDecimal(node.SelectSingleNode("ns:MirValupolFields/ns:MirDvValuPuaAmt", nsPV)?.InnerText);
                        valueInfo.DividendVCVonDeposit =
                            ParseDecimal(node.SelectSingleNode("ns:MirValupolFields/ns:MirPolDodAcumAmt", nsPV)?.InnerText);
                        valueInfo.DividendVCVonDepositInterest =
                            ParseDecimal(node.SelectSingleNode("ns:MirValupolFields/ns:MirDodCrntIntAmt", nsPV)?.InnerText);
                        valueInfo.TerminalBonusforSurrender =
                            ParseDecimal(node.SelectSingleNode("ns:MirValupolFields/ns:MirDvPolSurrAmt", nsPV)?.InnerText);
                        valueInfo.TotalBonus =
                            ParseDecimal(node.SelectSingleNode("ns:MirValupolFields/ns:MirDvPolBonCshAmt", nsPV)?.InnerText);
                        valueInfo.UnearnedPremium =
                            ParseDecimal(node.SelectSingleNode("ns:MirValupolFields/ns:MirDvPremRfndAmt", nsPV)?.InnerText);
                        valueInfo.ReturnofPremiumAmount =
                            ParseDecimal(node.SelectSingleNode("ns:MirValupolFields/ns:MirDvRopAmt", nsPV)?.InnerText);
                        valueInfo.CashValueofAccumulatedRevisionary =
                            ParseDecimal(node.SelectSingleNode("ns:MirValupolFields/ns:MirCvRbAcumAmt", nsPV)?.InnerText);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "SOAP InquiryPolicyValues failed for PolicyId={PolicyId}", policyId);
            }

            // ── 4. Cache & return ─────────────────────────────────────────────
            var cacheOptions = new MemoryCacheEntryOptions()
                .SetSlidingExpiration(_cacheDuration)
                .SetAbsoluteExpiration(TimeSpan.FromMinutes(15))
                .SetPriority(CacheItemPriority.High);

            _cache.Set(cacheKey, valueInfo, cacheOptions);

            sw.Stop();
            _logger.LogInformation(
                "ValueInfo OK PolicyId={PolicyId} Funds={FundCount} Time={Elapsed}ms",
                policyId, valueInfo.FundInformation.Count, sw.ElapsedMilliseconds);

            return valueInfo;
        }

        // ── SOAP Request Builders ─────────────────────────────────────────────
        private static XElement BuildInquiryFundValuesRequest(string policyId)
        {
            var soapNs = XNamespace.Get("http://schemas.xmlsoap.org/soap/envelope/");
            var TXLifeNs = XNamespace.Get("http://schema/webservices.elink.solcorp.com");
            var TXLifeNs1 = XNamespace.Get("http://ACORD.org/Standards/Life/2");
            var TXLifeNs2 = XNamespace.Get("http://www.w3.org/2001/XMLSchema-instance");
            var TXLifeNs3 = XNamespace.Get("http://www.w3.org/2001/XMLSchema");
            var TXLifeNs4 = XNamespace.Get("http://ACORD.org/Standards/Life/2../xsd/TXLife2.9.00.xsd");

            return new XElement(soapNs + "Envelope",
                new XAttribute(XNamespace.Xmlns + "soapenv", soapNs),
                new XAttribute(XNamespace.Xmlns + "web", TXLifeNs),
                new XElement(soapNs + "Header"),
                new XElement(soapNs + "Body",
                    new XElement(TXLifeNs1 + "TXLife",
                        new XAttribute(XNamespace.Xmlns + "xsi", TXLifeNs2),
                        new XAttribute(XNamespace.Xmlns + "xsd", TXLifeNs3),
                        new XAttribute(XNamespace.Xmlns + "schemaLocation", TXLifeNs4),
                        new XElement(TXLifeNs1 + "SignOnCompany", "CP"),
                        new XElement(TXLifeNs1 + "UserAuthRequest",
                            new XElement(TXLifeNs1 + "UserLoginName", "fi80w"),
                            new XElement(TXLifeNs1 + "UserPswd",
                                new XElement(TXLifeNs1 + "CryptType", "NONE"),
                                new XElement(TXLifeNs1 + "Pswd", "fi80w")),
                            new XElement(TXLifeNs1 + "UserCoId", "CP")),
                        new XElement("TXLifeRequest",
                            new XElement("TransRefGUID", ""),
                            new XElement("TransType", new XAttribute("tc", "InquiryFundValues"), ""),
                            new XElement("TransExeDate", ""),
                            new XElement("TransExeTime", ""),
                            new XElement("OLiFE",
                                new XElement("InquiryFundValuesData",
                                    new XElement("MirPolIdBase", policyId)))))));
        }

        private static XElement BuildInquiryPolicyValuesRequest(string policyId)
        {
            var soapNs = XNamespace.Get("http://schemas.xmlsoap.org/soap/envelope/");
            var TXLifeNs = XNamespace.Get("http://schema/webservices.elink.solcorp.com");
            var TXLifeNs1 = XNamespace.Get("http://ACORD.org/Standards/Life/2");
            var TXLifeNs2 = XNamespace.Get("http://www.w3.org/2001/XMLSchema-instance");
            var TXLifeNs3 = XNamespace.Get("http://www.w3.org/2001/XMLSchema");
            var TXLifeNs4 = XNamespace.Get("http://ACORD.org/Standards/Life/2../xsd/TXLife2.9.00.xsd");

            return new XElement(soapNs + "Envelope",
                new XAttribute(XNamespace.Xmlns + "soapenv", soapNs),
                new XAttribute(XNamespace.Xmlns + "web", TXLifeNs),
                new XElement(soapNs + "Header"),
                new XElement(soapNs + "Body",
                    new XElement(TXLifeNs1 + "TXLife",
                        new XAttribute(XNamespace.Xmlns + "xsi", TXLifeNs2),
                        new XAttribute(XNamespace.Xmlns + "xsd", TXLifeNs3),
                        new XAttribute(XNamespace.Xmlns + "schemaLocation", TXLifeNs4),
                        new XElement(TXLifeNs1 + "SignOnCompany", "CP"),
                        new XElement(TXLifeNs1 + "UserAuthRequest",
                            new XElement(TXLifeNs1 + "UserLoginName", "fi80w"),
                            new XElement(TXLifeNs1 + "UserPswd",
                                new XElement(TXLifeNs1 + "CryptType", "NONE"),
                                new XElement(TXLifeNs1 + "Pswd", "fi80w")),
                            new XElement(TXLifeNs1 + "UserCoId", "CP")),
                        new XElement("TXLifeRequest",
                            new XElement("TransRefGUID", ""),
                            new XElement("TransType", new XAttribute("tc", "InquiryPolicyValues"), ""),
                            new XElement("TransExeDate", ""),
                            new XElement("TransExeTime", ""),
                            new XElement("OLiFE",
                                new XElement("InquiryPolicyValuesData",
                                    new XElement("MirPolIdBase", policyId)))))));
        }

        // ── Helpers ───────────────────────────────────────────────────────────
        private static async Task<bool> CheckPolicyExistsAsync(SqlConnection connection, string policyId)
        {
            const string sql = @"
                SELECT CASE WHEN EXISTS (
                    SELECT 1 FROM DWM_POLICY WITH (NOLOCK)
                    WHERE POL_ID = @PolicyId
                ) THEN 1 ELSE 0 END";
            return await connection.ExecuteScalarAsync<bool>(sql, new { PolicyId = policyId });
        }

        // ✅ FIX: trailing comma before FROM removed in fund query
        private static string BuildOptimizedQuery() => @"
-- Query 1: Policy Value Information
SELECT DISTINCT
    TP.POL_ID                               AS PolicyId,
    ISNULL(TP.POL_OS_DISB_AMT,   0)        AS OutstandingDisbursements,
    ISNULL(TP.POL_PREM_SUSP_AMT, 0)        AS PremiumSuspense,
    ISNULL(TP.POL_MISC_SUSP_AMT, 0)        AS MiscellaneousSuspense,
    CAST(0 AS DECIMAL(18,2))               AS MaximumLoanAmountAvailable,
    ISNULL(PL.LOAN_AMT,          0)        AS LoanAmount,
    ISNULL(PL.LOAN_INT_YTD_AMT,  0)        AS LoanInterestPaidCapitalizedYTD,
    ISNULL(PL.LOAN_AMT,          0)        AS APLAmount,
    ISNULL(PL.LOAN_AVB_AMT,      0)        AS APLInterestPaidCapitalizedYTD,
    ISNULL(PX.TAXBL_PREM_PD_AMT, 0)        AS TotalPremiumsPaid
FROM DWM_POLICY TP WITH (NOLOCK)
LEFT JOIN DWA_POLICY_LOAN PL WITH (NOLOCK) ON PL.POL_ID = TP.POL_ID
LEFT JOIN DWA_POLICY_TAX  PX WITH (NOLOCK) ON PX.POL_ID = TP.POL_ID
WHERE TP.POL_ID = @PolicyId
OPTION (MAXDOP 2);

-- Query 2: Fund Information
WITH MaxEffDate AS (
    SELECT MAX(FIA_EFF_DT) AS MaxDate
    FROM DWT_FIA WITH (NOLOCK)
    WHERE POL_ID = @PolicyId
)
SELECT
    ISNULL(FI.FND_ID,              '')     AS Fund,
    ISNULL(FI.FIA_AUNIT_PRIC_AMT,  0)     AS UnitPrice,
    ISNULL(FI.CFN_INTG_AUNIT_QTY,  0)     AS ApproximateNumberofUnits
FROM DWT_FIA FI WITH (NOLOCK)
CROSS JOIN MaxEffDate
WHERE FI.POL_ID       = @PolicyId
  AND FI.FIA_EFF_DT   = MaxEffDate.MaxDate
OPTION (MAXDOP 2);";

        private static decimal ParseDecimal(string? value) =>
            decimal.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out var result)
                ? result : 0m;
    }
}