using SalesforcAPI.Interfaces;
using SalesforcAPI.Repositories;
using SalesforcAPI.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();
builder.Services.AddHttpClient();                                      // required for IHttpClientFactory
builder.Services.AddScoped<IRequestSoap, RequestSoap>();               // ? register SOAP service
builder.Services.AddScoped<IValueInformationRepository, ValueInformationRepository>();
builder.Services.AddMemoryCache();
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
