﻿// Models/ValueInformationModels.cs
using System;
using System.Collections.Generic;

namespace SalesforcAPI.Models
{
    public class ValueInformationRequest
    {
        public string PolicyId { get; set; } = string.Empty;
    }

    public class ValueInformationResponse
    {
        public string PolicyId { get; set; } = string.Empty;

        // From SOAP - InquiryFundValues
        public decimal MCVNetBaseCaseValue { get; set; }
        public decimal SurrenderCharge { get; set; }
        public decimal CashSurrenderValue { get; set; }

        // From SOAP - InquiryPolicyValues
        public decimal PaidupAdditionsCaseValue { get; set; }
        public decimal DividendVCVonDeposit { get; set; }
        public decimal DividendVCVonDepositInterest { get; set; }
        public decimal TerminalBonusforSurrender { get; set; }
        public decimal TotalBonus { get; set; }
        public decimal UnearnedPremium { get; set; }
        public decimal ReturnofPremiumAmount { get; set; }
        public decimal CashValueofAccumulatedRevisionary { get; set; }

        // From SQL
        public decimal OutstandingDisbursements { get; set; }
        public decimal PremiumSuspense { get; set; }
        public decimal MiscellaneousSuspense { get; set; }
        public decimal MaximumLoanAmountAvailable { get; set; }
        public decimal LoanAmount { get; set; }
        public decimal LoanInterestPaidCapitalizedYTD { get; set; }
        public decimal APLAmount { get; set; }
        public decimal APLInterestPaidCapitalizedYTD { get; set; }
        public decimal TotalPremiumsPaid { get; set; }

        public List<FundInformation>? FundInformation { get; set; }
    }

    public class FundInformation
    {
        public string Fund { get; set; } = string.Empty;
        public decimal UnitPrice { get; set; }
        public decimal ApproximateNumberofUnits { get; set; }  // ✅ FIX: missing closing brace
        public decimal BaseCashValue { get; set; }
        public decimal CashSurrenderValue { get; set; }
        public decimal FundPercentage { get; set; }
    }

    public class ApiSuccessResponse<T>
    {
        public bool Success { get; set; }
        public string Message { get; set; } = string.Empty;
        public T? Data { get; set; }
        public DateTime Timestamp { get; set; }
    }

    // ✅ FIX: ApiErrorResponse was missing entirely
    public class ApiErrorResponse
    {
        public bool Success { get; set; }
        public string ErrorCode { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public DateTime Timestamp { get; set; }
    }
}