﻿// Interfaces/IValueInformationRepository.cs
using SalesforcAPI.Models;
using System.Threading.Tasks;

namespace SalesforcAPI.Interfaces
{
    public interface IValueInformationRepository
    {
        Task<ValueInformationResponse?> GetValueInformationAsync(string policyId);
    }
}