﻿// Interfaces/IRequestSoap.cs
namespace SalesforcAPI.Interfaces
{
    public interface IRequestSoap
    {
        string PostSOAPRequestAsync(string url, string soapBody);
    }
}