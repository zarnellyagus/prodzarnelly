﻿// Services/RequestSoap.cs
using SalesforcAPI.Interfaces;
using System.Net.Http;
using System.Text;

namespace SalesforcAPI.Services
{
    public class RequestSoap : IRequestSoap
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public RequestSoap(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public string PostSOAPRequestAsync(string url, string soapBody)
        {
            var client = _httpClientFactory.CreateClient();
            var content = new StringContent(soapBody, Encoding.UTF8, "text/xml");
            content.Headers.Add("SOAPAction", "\"\"");

            var response = client.PostAsync(url, content).GetAwaiter().GetResult();
            response.EnsureSuccessStatusCode();

            return response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
        }
    }
}