﻿// Controllers/ValueInformationController.cs
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SalesforcAPI.Interfaces;
using SalesforcAPI.Models;
using System;
using System.Threading.Tasks;

namespace SalesForcAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValueInformationController : ControllerBase
    {
        private readonly IValueInformationRepository _repository;
        private readonly ILogger<ValueInformationController> _logger;

        public ValueInformationController(
            IValueInformationRepository repository,
            ILogger<ValueInformationController> logger)
        {
            _repository = repository;
            _logger = logger;
        }

        [HttpPost]
        [ResponseCache(Duration = 300, VaryByQueryKeys = new[] { "PolicyId" })]
        [ProducesResponseType(typeof(ApiSuccessResponse<ValueInformationResponse>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> Post([FromBody] ValueInformationRequest request)
        {
            try
            {
                if (request == null || string.IsNullOrWhiteSpace(request.PolicyId))
                {
                    _logger.LogWarning("ValueInformation POST called with invalid or empty PolicyId");
                    return BadRequest(new ApiErrorResponse
                    {
                        Success = false,
                        ErrorCode = "INVALID_REQUEST",
                        Message = "PolicyId is required and cannot be empty",
                        Timestamp = DateTime.UtcNow
                    });
                }

                _logger.LogInformation("Fetching value information for PolicyId={PolicyId}", request.PolicyId);

                var result = await _repository.GetValueInformationAsync(request.PolicyId);
                if (result == null)
                {
                    _logger.LogWarning("Policy NOT FOUND PolicyId={PolicyId}", request.PolicyId);
                    return NotFound(new ApiErrorResponse
                    {
                        Success = false,
                        ErrorCode = "POLICY_NOT_FOUND",
                        Message = $"Policy with ID '{request.PolicyId}' does not exist",
                        Timestamp = DateTime.UtcNow
                    });
                }

                return Ok(new ApiSuccessResponse<ValueInformationResponse>
                {
                    Success = true,
                    Message = "Value information retrieved successfully",
                    Data = result,
                    Timestamp = DateTime.UtcNow
                });
            }
            catch (Microsoft.Data.SqlClient.SqlException sqlEx)
            {
                _logger.LogError(sqlEx,
                    "Database error for PolicyId={PolicyId} ErrorCode={ErrorCode}",
                    request?.PolicyId, sqlEx.Number);
                return StatusCode(StatusCodes.Status500InternalServerError, new ApiErrorResponse
                {
                    Success = false,
                    ErrorCode = $"SQL_ERROR_{sqlEx.Number}",
                    Message = "Database error occurred while processing your request",
                    Timestamp = DateTime.UtcNow
                });
            }
            catch (ArgumentException argEx)
            {
                _logger.LogWarning(argEx, "Validation error for PolicyId={PolicyId}", request?.PolicyId);
                return BadRequest(new ApiErrorResponse
                {
                    Success = false,
                    ErrorCode = "VALIDATION_ERROR",
                    Message = argEx.Message,
                    Timestamp = DateTime.UtcNow
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    "Unexpected error for PolicyId={PolicyId}", request?.PolicyId);
                return StatusCode(StatusCodes.Status500InternalServerError, new ApiErrorResponse
                {
                    Success = false,
                    ErrorCode = "INTERNAL_ERROR",
                    Message = "An unexpected error occurred while processing your request",
                    Timestamp = DateTime.UtcNow
                });
            }
        }
    }
}