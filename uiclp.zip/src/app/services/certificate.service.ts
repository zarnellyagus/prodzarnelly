import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Certificate, CertificateFilter, PagedResult } from '../models/certificate.model';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class CertificateService {
  private http = inject(HttpClient);
  private base = `${environment.apiUrl}/api/certificate`;

  // GET list via query params → GET /api/certificate?...
  getList(filter: CertificateFilter): Observable<PagedResult<Certificate>> {
    let params = new HttpParams()
      .set('pageNumber',    filter.pageNumber.toString())
      .set('pageSize',      filter.pageSize.toString())
      .set('sortColumn',    filter.sortColumn)
      .set('sortDirection', filter.sortDirection);

    if (filter.memberID)          params = params.set('memberID',          filter.memberID);
    if (filter.companyID)         params = params.set('companyID',         filter.companyID);
    if (filter.policyID)          params = params.set('policyID',          filter.policyID);
    if (filter.certificateID)     params = params.set('certificateID',     filter.certificateID);
    if (filter.certificateStatus) params = params.set('certificateStatus', filter.certificateStatus);
    if (filter.insuredName)       params = params.set('insuredName',       filter.insuredName);

    return this.http.get<PagedResult<Certificate>>(this.base, { params });
  }

  // POST search via body → POST /api/certificate/search
  search(filter: CertificateFilter): Observable<PagedResult<Certificate>> {
    return this.http.post<PagedResult<Certificate>>(`${this.base}/search`, filter);
  }

  // GET detail → GET /api/certificate/{memberId}?companyId=
  getByMemberId(memberId: string, companyId: string): Observable<Certificate> {
    const params = new HttpParams().set('companyId', companyId);
    return this.http.get<Certificate>(`${this.base}/${memberId}`, { params });
  }
}