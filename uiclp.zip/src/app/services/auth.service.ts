import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, throwError } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';
import { LoginRequest, LoginResponse, Company, UserProfile } from '../models/auth.model';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly http   = inject(HttpClient);
  private readonly router = inject(Router);
  private readonly baseUrl = 'https://localhost:7201/api/auth';

  // ── LOGIN via LDAP + DB ──────────────────────────────
  login(username: string, password: string, companyID?: string): Observable<LoginResponse> {
    // companyID bisa dikirim dari form; jika tidak ada, pakai default
    const req: LoginRequest = {
      username,
      password,
      companyID: companyID || this.getSelectedCompanyID() || '01'
    };

    return this.http.post<LoginResponse>(`${this.baseUrl}/login`, req).pipe(
      tap(res => {
        if (res.success) {
          // Simpan token & profile ke sessionStorage
          sessionStorage.setItem('token',       res.token);
          sessionStorage.setItem('userID',      res.userID);
          sessionStorage.setItem('companyID',   res.companyID);
          sessionStorage.setItem('companyName', res.companyName);
          sessionStorage.setItem('expiresAt',   res.expiresAt);
          this.router.navigate(['/dashboard']);
        }
      }),
      catchError(err => {
        const msg = err.error?.message || 'Login gagal. Periksa username/password.';
        return throwError(() => new Error(msg));
      })
    );
  }

  // ── COMPANIES untuk dropdown ──────────────────────────
  getCompanies(): Observable<Company[]> {
    return this.http.get<Company[]>(`${this.baseUrl}/companies`);
  }

  // ── PROFILE dari token ────────────────────────────────
  getProfile(): Observable<UserProfile> {
    return this.http.get<UserProfile>(`${this.baseUrl}/profile`);
  }

  // ── HELPERS ──────────────────────────────────────────
  isAuthenticated(): boolean {
    const token     = sessionStorage.getItem('token');
    const expiresAt = sessionStorage.getItem('expiresAt');
    if (!token || !expiresAt) return false;
    return new Date(expiresAt) > new Date();
  }

  getToken(): string | null     { return sessionStorage.getItem('token'); }
  getUserID(): string           { return sessionStorage.getItem('userID')      ?? ''; }
  getCompanyID(): string        { return sessionStorage.getItem('companyID')   ?? ''; }
  getCompanyName(): string      { return sessionStorage.getItem('companyName') ?? ''; }
  getSelectedCompanyID(): string { return sessionStorage.getItem('companyID')  ?? ''; }

  getCurrentUser() {
    return {
      name:    this.getUserID(),
      email:   `${this.getUserID()}@${this.getCompanyID()}.com`.toLowerCase(),
      company: this.getCompanyName(),
      avatar:  'account_circle'
    };
  }

  logout(): void {
    sessionStorage.clear();
    this.router.navigate(['/login']);
  }

  // SSO stub — tetap ada agar login.component.ts tidak error
  loginWithAzureSSO(): void {
    console.warn('Azure SSO not configured. Use LDAP login.');
    this.router.navigate(['/login'], { queryParams: { error: 'sso_failed' } });
  }
}