import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { CommonModule, DatePipe, CurrencyPipe } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup } from '@angular/forms';
import { CertificateService } from '../../services/certificate.service';
import { Certificate, CertificateFilter } from '../../models/certificate.model';

@Component({
  selector: 'app-certificate-list',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, DatePipe],
  templateUrl: './certificate-list.component.html',
  styleUrl: './certificate-list.component.css'
})
export class CertificateListComponent implements OnInit {
  private svc = inject(CertificateService);
  private fb = inject(FormBuilder);

  certificates = signal<Certificate[]>([]);
  totalRecords = signal(0);
  totalPages = signal(0);
  isLoading = signal(false);
  errorMessage = signal('');
  selectedItem = signal<Certificate | null>(null);

  pageNumber = signal(1);
  pageSize = signal(20);
  sortColumn = signal('EffectiveDate');
  sortDir = signal<'ASC' | 'DESC'>('DESC');

  startRow = computed(() => (this.pageNumber() - 1) * this.pageSize() + 1);
  endRow = computed(() => Math.min(this.pageNumber() * this.pageSize(), this.totalRecords()));
  pages = computed(() => Array.from({ length: this.totalPages() }, (_, i) => i + 1));

  filterForm: FormGroup = this.fb.group({
    memberID: [''],
    companyID: [''],
    policyID: [''],
    certificateID: [''],
    certificateStatus: [''],
    insuredName: [''],
  });

  statusOptions = [
    { code: '', label: 'All Status' },
    { code: 'ACT', label: 'Active' },
    { code: 'LAP', label: 'Lapsed' },
    { code: 'TRM', label: 'Terminated' },
    { code: 'PND', label: 'Pending' },
  ];

  ngOnInit(): void { this.loadData(); }

  loadData(): void {
    this.isLoading.set(true);
    this.errorMessage.set('');
    const f = this.filterForm.value;

    const filter: CertificateFilter = {
      memberID: f.memberID || undefined,
      companyID: f.companyID || undefined,
      policyID: f.policyID || undefined,
      certificateID: f.certificateID || undefined,
      certificateStatus: f.certificateStatus || undefined,
      insuredName: f.insuredName || undefined,
      pageNumber: this.pageNumber(),
      pageSize: this.pageSize(),
      sortColumn: this.sortColumn(),
      sortDirection: this.sortDir(),
    };

    this.svc.getList(filter).subscribe({
      next: (res) => {
        this.certificates.set(res.data);
        this.totalRecords.set(res.totalRecords);
        this.totalPages.set(res.totalPages);
        this.isLoading.set(false);
      },
      error: (err) => {
        this.errorMessage.set(err?.error?.message ?? 'Failed to load data');
        this.isLoading.set(false);
      }
    });
  }

  search(): void { this.pageNumber.set(1); this.loadData(); }

  resetFilter(): void {
    this.filterForm.reset({
      memberID: '', companyID: '', policyID: '',
      certificateID: '', certificateStatus: '', insuredName: ''
    });
    this.pageNumber.set(1);
    this.loadData();
  }

  sort(col: string): void {
    if (this.sortColumn() === col) {
      this.sortDir.set(this.sortDir() === 'ASC' ? 'DESC' : 'ASC');
    } else {
      this.sortColumn.set(col);
      this.sortDir.set('ASC');
    }
    this.loadData();
  }

  sortIcon(col: string): string {
    return this.sortColumn() !== col ? '↕' : this.sortDir() === 'ASC' ? '↑' : '↓';
  }

  goToPage(page: number): void {
    if (page < 1 || page > this.totalPages()) return;
    this.pageNumber.set(page);
    this.loadData();
  }

  openDetail(item: Certificate): void { this.selectedItem.set(item); }
  closeDetail(): void { this.selectedItem.set(null); }

  getStatusClass(status: string | null): string {
    const map: Record<string, string> = {
      ACT: 'status-done',
      LAP: 'status-pending',
      TRM: 'status-cancelled',
      PND: 'status-draft',
    };
    return map[status ?? ''] ?? 'status-secondary';
  }
}