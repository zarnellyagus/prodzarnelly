using System.ComponentModel.DataAnnotations;

namespace salesforcewsdl.Models
{
    public class AnticipatedEndowmentRequest
    {
        [Required]
        public string PolicyID { get; set; } = string.Empty;
    }
}
