# Ingenium API Core 8 - On The Fly + Swagger

ASP.NET Core 8 Web API yang siap compile, memakai Swagger, typed `HttpClient`, `IOptions`, dan mapping XML TXLife langsung di dalam service.

## Package

Project ini sudah menyertakan package:

- `Swashbuckle.AspNetCore`

## Endpoint

### POST `/api/ingenium/anticipated-endowment`

Request body:

```json
{
  "policyID": "POL12345601"
}
```

## Jalankan

```bash
dotnet restore
dotnet build
dotnet run
```

Lalu buka:

- `http://localhost:5099/swagger`
- atau `https://localhost:7148/swagger`

## Catatan

- `AddSwaggerGen()` akan jalan karena package `Swashbuckle.AspNetCore` sudah direferensikan di `.csproj`.
- Mapping response XML dilakukan langsung di `Services/IngeniumService.cs`.
- Sesuaikan konfigurasi `TXLife` di `appsettings.json` sebelum testing.
