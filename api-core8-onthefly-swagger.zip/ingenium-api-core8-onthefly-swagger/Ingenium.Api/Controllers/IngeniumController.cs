using Ingenium.Api.Services;
using Microsoft.AspNetCore.Mvc;
using salesforcewsdl.Models;

namespace Ingenium.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class IngeniumController : ControllerBase
{
    private readonly IIngeniumService _ingeniumService;

    public IngeniumController(IIngeniumService ingeniumService)
    {
        _ingeniumService = ingeniumService;
    }

    [HttpPost("anticipated-endowment")]
    [ProducesResponseType(typeof(AnticipatedEndowmentResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> AnticipatedEndowment(
        [FromBody] AnticipatedEndowmentRequest request,
        CancellationToken cancellationToken)
    {
        var result = await _ingeniumService.InquiryAnticipatedEndowmentAsync(
            request.PolicyID,
            cancellationToken);

        return Ok(result);
    }
}
