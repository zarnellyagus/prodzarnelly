using System.ComponentModel.DataAnnotations;

namespace Ingenium.Api.Options;

public class TXLifeSettings
{
    public const string SectionName = "TXLife";

    [Required]
    public string ServiceUrl { get; set; } = string.Empty;

    [Required]
    public string Username { get; set; } = string.Empty;

    [Required]
    public string Password { get; set; } = string.Empty;

    [Required]
    public string CompanyCode { get; set; } = string.Empty;

    [Required]
    public string FunctionId { get; set; } = string.Empty;
}
