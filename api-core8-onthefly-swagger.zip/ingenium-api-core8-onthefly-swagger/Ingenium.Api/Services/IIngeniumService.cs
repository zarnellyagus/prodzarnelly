using salesforcewsdl.Models;

namespace Ingenium.Api.Services;

public interface IIngeniumService
{
    Task<AnticipatedEndowmentResponse> InquiryAnticipatedEndowmentAsync(string policyId, CancellationToken cancellationToken = default);
}
