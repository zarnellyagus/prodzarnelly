// report/report.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ReportService, ConsolidatedParams } from '../services/report.service';
import { ExcelExportService } from '../services/excel-export.service';

@Component({
  selector: 'app-report',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './report.component.html',
  styleUrls:   ['./report.component.scss']
})
export class ReportComponent {

  // ── Filter Params ─────────────────────────────────────────
  startDate    = '';
  endDate      = '';
  policyID     = '';
  appNo        = '';
  settleDate   = '';
  downloadDate = '';

  // ── Date Type Combobox ────────────────────────────────────
  dateType: 'settleDate' | 'downloadDate' | '' = '';

  // ── State ─────────────────────────────────────────────────
  isLoading   = false;
  isExporting = false;
  errorMsg    = '';
  successMsg  = '';
  totalRows   = 0;

  constructor(
    private reportSvc: ReportService,
    private excelSvc:  ExcelExportService
  ) {}

  // ── Reset tanggal kondisional saat ganti date type ────────
  onDateTypeChange(): void {
    this.settleDate   = '';
    this.downloadDate = '';
    this.errorMsg     = '';
  }

  // ── Validasi internal ─────────────────────────────────────
  private validate(): string {
    if (!this.startDate) return 'Start Date wajib diisi.';
    if (!this.endDate)   return 'End Date wajib diisi.';
    if (this.startDate > this.endDate)
      return 'Start Date tidak boleh lebih besar dari End Date.';
    if (this.dateType === 'settleDate' && !this.settleDate)
      return 'Settle Date wajib diisi karena Date Type = Settle Date.';
    if (this.dateType === 'downloadDate' && !this.downloadDate)
      return 'Download Date wajib diisi karena Date Type = Download Date.';
    return '';
  }

  // ── Run ───────────────────────────────────────────────────
  onRun(): void {
    this.errorMsg   = '';
    this.successMsg = '';
    this.totalRows  = 0;

    const validationError = this.validate();
    if (validationError) {
      this.errorMsg = validationError;
      return;
    }

    this.isLoading = true;

    const payload: ConsolidatedParams = {
      startDate:    this.startDate,
      endDate:      this.endDate,
      policyID:     this.policyID     || undefined,
      appNo:        this.appNo        || undefined,
      dateType:     this.dateType     || undefined,
      settleDate:   this.dateType === 'settleDate'
                      ? this.settleDate   : undefined,
      downloadDate: this.dateType === 'downloadDate'
                      ? this.downloadDate : undefined
    };

    this.reportSvc.getConsolidated(payload).subscribe({
      next: async (res) => {
        this.isLoading = false;

        if (!res.success || res.total === 0) {
          this.errorMsg = 'Tidak ada data ditemukan.';
          return;
        }

        this.totalRows  = res.total;
        this.isExporting = true;

        try {
          await this.excelSvc.exportConsolidated(
            res.columns, res.data, 'ConsolidatedReport'
          );
          this.successMsg =
            `Berhasil export ${res.total.toLocaleString('id-ID')} baris data ke Excel.`;
        } catch {
          this.errorMsg = 'Gagal membuat file Excel.';
        } finally {
          this.isExporting = false;
        }
      },
      error: (err: any) => {
        this.isLoading = false;
        this.errorMsg  = err?.error?.message ?? 'Gagal mengambil data dari server.';
      }
    });
  }

  // ── Reset ─────────────────────────────────────────────────
  onReset(): void {
    this.startDate    = '';
    this.endDate      = '';
    this.policyID     = '';
    this.appNo        = '';
    this.settleDate   = '';
    this.downloadDate = '';
    this.dateType     = '';
    this.errorMsg     = '';
    this.successMsg   = '';
    this.totalRows    = 0;
  }
}