// app-routing.module.ts
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './guards/auth.guard';

const routes: Routes = [
  {
    path: '',
    redirectTo: '/login',
    pathMatch: 'full'
  },
  {
    path: 'login',
    loadComponent: () =>
      import('./login/login.component').then(c => c.LoginComponent)
  },
  {
    path: '',                        // ← layout shell DashboardComponent
    loadComponent: () =>
      import('./dashboard/dashboard.component').then(c => c.DashboardComponent),
    canActivate: [AuthGuard],
    children: [
      {
        path: 'dashboard',
        loadComponent: () =>
          import('./new-dashboard/new-dashboard.component').then(c => c.NewDashboardComponent)
      },
      {
        path: 'consolidate-policy',
        loadComponent: () =>
          import('./consolidate-policy/consolidate-policy.component').then(c => c.ConsolidatePolicyComponent)
      },
      {
        path: 'report',              // ← pastikan ada di sini
        loadComponent: () =>
          import('./report/report.component').then(c => c.ReportComponent)
      },
      {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full'
      }
    ]
  },
  {
    path: '**',
    redirectTo: '/login'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}