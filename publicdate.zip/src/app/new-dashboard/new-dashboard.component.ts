import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';

export interface DashboardMenu {
  id: string;
  title: string;
  description: string;
  icon: string;
  route: string;
  badge?: string;
  badgeColor?: string;
  stats?: { label: string; value: string }[];
}

@Component({
  selector: 'app-new-dashboard',
  standalone: true,
  imports: [
    CommonModule,   // *ngIf, *ngFor, [ngClass], date pipe
    RouterModule    // routerLink, routerLinkActive
  ],
  templateUrl: './new-dashboard.component.html',
  styleUrls: ['./new-dashboard.component.scss']
})
export class NewDashboardComponent implements OnInit {
  currentDate = new Date();

  menuCards: DashboardMenu[] = [
    {
      id: 'consolidate-policy',
      title: 'Consolidate Policy',
      description: 'Kelola dan konsolidasikan kebijakan perusahaan dari berbagai cabang menjadi satu dokumen terpadu.',
      icon: 'fas fa-file-contract',
      route: '/consolidate-policy',
      badge: 'Active',
      badgeColor: 'success',
      stats: [
        { label: 'Total Policy', value: '24' },
        { label: 'Pending Review', value: '5' },
        { label: 'Approved', value: '19' }
      ]
    },
    {
      id: 'report',
      title: 'Report',
      description: 'Buat dan ekspor laporan komprehensif berdasarkan data konsolidasi kebijakan dan transaksi.',
      icon: 'fas fa-chart-bar',
      route: '/report',
      badge: 'New',
      badgeColor: 'primary',
      stats: [
        { label: 'Total Report', value: '12' },
        { label: 'This Month', value: '3' },
        { label: 'Exported', value: '9' }
      ]
    }
  ];

  constructor(private router: Router) {}

  ngOnInit(): void {}

  navigateTo(route: string): void {
    this.router.navigate([route]);
  }
}