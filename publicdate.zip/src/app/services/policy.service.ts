// services/policy.service.ts
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

// ─── Models ─────────────────────────────────────────────────────

export interface PagedResult<T> {
  data:         T[];
  totalRecords: number;
  pageNumber:   number;
  pageSize:     number;
  totalPages:   number;
}

export interface ConsolidatePolicy {
  companyID:   string;
  policyID:    string;
  appNo:       string;
  ownerName:   string;
  issuedDate:  string | null;
}

export interface PolicyDetail {
  spajNo:      string;
  policyNo:    string;
  clientID:    string;
  ownerName:   string;
  insuredName: string;
  planName:    string;
  issuedDate:  string | null;
  agentId:     string;
  branchName:  string;
  addressName: string;
  email:       string;
  tlpNum:      string;
  ttp:         string;
  receiveDate: string;
}

export interface EPolicyStatus {
  ePolSource:  string;
  statusDate:  string | null;
}

export interface PolicySummary {
  polSumPolicyID:   string;
  polSumPickUpDate: string | null;
  polSumStatusDate: string | null;
  polSumStatus:     string;
  polSumReceiver:   string;
  polSumRelation:   string;
  polSumReturn:     string;
  polSumResiNo:     string;
  polSumCourier:    string;
}

export interface ReturnSms {
  rsSendDate: string | null;
  rsStatus:   string;
}

// ─── Service ────────────────────────────────────────────────────

@Injectable({ providedIn: 'root' })
export class PolicyService {
  private baseUrl = 'http://localhost:7147/api/policy';

  constructor(private http: HttpClient) {}

  // ── Consolidate List (Paged) ───────────────────────────────────
  getConsolidatePolicies(
    policyId?:  string,
    appNo?:     string,
    pageNumber  = 1,
    pageSize    = 10
  ): Observable<PagedResult<ConsolidatePolicy>> {
    let params = new HttpParams()
      .set('pageNumber', pageNumber)
      .set('pageSize',   pageSize);

    if (policyId?.trim()) params = params.set('policyId', policyId.trim());
    if (appNo?.trim())    params = params.set('appNo',    appNo.trim());

    return this.http.get<PagedResult<ConsolidatePolicy>>(
      `${this.baseUrl}/consolidate`, { params }
    );
  }

  // ── Policy Detail ─────────────────────────────────────────────
  getPolicyDetail(policyId: string): Observable<PolicyDetail> {
    return this.http.get<PolicyDetail>(
      `${this.baseUrl}/detail/${policyId}`
    );
  }

  // ── E-Policy Status (NEW) ─────────────────────────────────────
  getEPolicyStatus(policyId: string): Observable<EPolicyStatus[]> {
    return this.http.get<EPolicyStatus[]>(
      `${this.baseUrl}/epolicy-status/${policyId}`
    );
  }

  // ── Policy Summary (NEW) ──────────────────────────────────────
  getPolicySummary(policyId: string): Observable<PolicySummary[]> {
    return this.http.get<PolicySummary[]>(
      `${this.baseUrl}/policy-summary/${policyId}`
    );
  }

  // ── Return SMS ────────────────────────────────────────────────
  getReturnSms(policyId: string): Observable<ReturnSms[]> {
    return this.http.get<ReturnSms[]>(
      `${this.baseUrl}/return-sms/${policyId}`
    );
  }

  // ── Resend E-Policy ───────────────────────────────────────────
  getResendEPolicy(policyId: string): Observable<EPolicyStatus[]> {
    return this.http.get<EPolicyStatus[]>(
      `${this.baseUrl}/resend-epolicy/${policyId}`
    );
  }

  // ── Resend Policy Summary ─────────────────────────────────────
  getResendPolicySummary(policyId: string): Observable<PolicySummary[]> {
    return this.http.get<PolicySummary[]>(
      `${this.baseUrl}/resend-summary/${policyId}`
    );
  }
}