// services/excel-export.service.ts
import { Injectable } from '@angular/core';
import * as ExcelJS from 'exceljs';
import { saveAs } from 'file-saver';

@Injectable({ providedIn: 'root' })
export class ExcelExportService {

  async exportConsolidated(
    columns: string[],
    data:    Record<string, any>[],
    fileName = 'ConsolidatedReport'
  ): Promise<void> {

    const wb = new ExcelJS.Workbook();
    wb.creator  = 'Sun Life Indonesia';
    wb.created  = new Date();

    const ws = wb.addWorksheet('Consolidated Report', {
      views: [{ state: 'frozen', ySplit: 3 }]  // freeze 3 baris atas
    });

    // ── Title Row ──────────────────────────────────────────────
    ws.mergeCells(1, 1, 1, columns.length);
    const titleCell = ws.getCell('A1');
    titleCell.value = 'CONSOLIDATED REPORT — SUN LIFE INDONESIA';
    titleCell.font  = { name: 'Calibri', bold: true, size: 13, color: { argb: 'FFFFFFFF' } };
    titleCell.alignment = { horizontal: 'center', vertical: 'middle' };
    titleCell.fill  = {
      type: 'pattern', pattern: 'solid',
      fgColor: { argb: 'FF0E3846' }
    };
    ws.getRow(1).height = 28;

    // ── Subtitle Row ───────────────────────────────────────────
    ws.mergeCells(2, 1, 2, columns.length);
    const subCell = ws.getCell('A2');
    subCell.value = `Generated: ${new Date().toLocaleString('id-ID')}  |  Total Records: ${data.length}`;
    subCell.font  = { name: 'Calibri', italic: true, size: 10, color: { argb: 'FF555555' } };
    subCell.alignment = { horizontal: 'center', vertical: 'middle' };
    subCell.fill  = {
      type: 'pattern', pattern: 'solid',
      fgColor: { argb: 'FFECAB23' }
    };
    ws.getRow(2).height = 20;

    // ── Header Row (row 3) ─────────────────────────────────────
    const headerRow = ws.getRow(3);
    columns.forEach((col, i) => {
      const cell = headerRow.getCell(i + 1);
      cell.value = col;
      cell.font  = { name: 'Calibri', bold: true, size: 10, color: { argb: 'FFFFFFFF' } };
      cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
      cell.fill  = {
        type: 'pattern', pattern: 'solid',
        fgColor: { argb: 'FF1B5E6F' }
      };
      cell.border = {
        top:    { style: 'thin', color: { argb: 'FFECAB23' } },
        bottom: { style: 'thin', color: { argb: 'FFECAB23' } },
        left:   { style: 'thin', color: { argb: 'FFECAB23' } },
        right:  { style: 'thin', color: { argb: 'FFECAB23' } },
      };
    });
    headerRow.height = 32;

    // ── Data Rows ──────────────────────────────────────────────
    data.forEach((row, rowIdx) => {
      const exRow = ws.addRow(columns.map(col => row[col] ?? ''));
      const isEven = rowIdx % 2 === 1;

      exRow.eachCell({ includeEmpty: true }, (cell) => {
        cell.font      = { name: 'Calibri', size: 10 };
        cell.alignment = { vertical: 'middle', wrapText: false };
        cell.fill      = {
          type: 'pattern', pattern: 'solid',
          fgColor: { argb: isEven ? 'FFF4F5F7' : 'FFFFFFFF' }
        };
        cell.border = {
          bottom: { style: 'hair', color: { argb: 'FFDDE1E6' } },
          right:  { style: 'hair', color: { argb: 'FFDDE1E6' } },
        };
      });
      exRow.height = 18;
    });

    // ── Column widths ──────────────────────────────────────────
    const colWidthMap: Record<string, number> = {
      SeqNo: 7, settle_date: 14, spajno: 16, policyno: 16,
      Owner_name: 28, agnt_id: 12, agnt_name: 24, BranchName: 22,
      addressnm: 36, email: 28, tlpnum: 16, dob: 14,
    };
    columns.forEach((col, i) => {
      ws.getColumn(i + 1).width = colWidthMap[col] ?? 16;
    });

    // ── Export ─────────────────────────────────────────────────
    const buffer = await wb.xlsx.writeBuffer();
    const blob   = new Blob([buffer], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    });
    const name = `${fileName}_${new Date().toISOString().slice(0,10)}.xlsx`;
    saveAs(blob, name);
  }
}