// services/report.service.ts
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface ConsolidatedResponse {
  success: boolean;
  total:   number;
  columns: string[];
  data:    Record<string, any>[];
}

export interface ConsolidatedParams {
  startDate:     string;
  endDate:       string;
  policyID?:     string;
  appNo?:        string;
  settleDate?:   string;
  downloadDate?: string;
  dateType?:     'settleDate' | 'downloadDate' | '';
}

@Injectable({ providedIn: 'root' })
export class ReportService {
  private baseUrl = 'https://localhost:7147/api/report';

  constructor(private http: HttpClient) {}

  getConsolidated(p: ConsolidatedParams): Observable<ConsolidatedResponse> {
    let params = new HttpParams()
      .set('startDate', p.startDate)
      .set('endDate',   p.endDate);

    if (p.policyID?.trim())     params = params.set('policyID',     p.policyID.trim());
    if (p.appNo?.trim())        params = params.set('appNo',        p.appNo.trim());
    if (p.dateType?.trim())     params = params.set('dateType',     p.dateType.trim());
    if (p.settleDate?.trim())   params = params.set('settleDate',   p.settleDate.trim());
    if (p.downloadDate?.trim()) params = params.set('downloadDate', p.downloadDate.trim());

    return this.http.get<ConsolidatedResponse>(
      `${this.baseUrl}/consolidated`, { params }
    );
  }
}