import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthService, MenuItem } from '../services/auth.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [
    CommonModule,       // *ngIf, *ngFor, pipes
    RouterModule,       // seluruh router directives
    RouterLink,         // [routerLink] directive
    RouterLinkActive,   // routerLinkActive directive
    RouterOutlet        // <router-outlet>
  ],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  sidebarCollapsed = false;
  currentUser: any;
  menuItems: MenuItem[] = [];

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.currentUser = this.authService.getCurrentUser();
    if (!this.currentUser) {
      this.router.navigate(['/login']);
      return;
    }
    this.loadUserMenu();
  }

  loadUserMenu(): void {
    this.authService.getUserMenu(this.currentUser.userID, this.currentUser.companyID)
      .subscribe({
        next: (menuItems) => {
          this.menuItems = menuItems;
        },
        error: (error) => {
          console.error('Error loading menu:', error);
        }
      });
  }

  toggleSidebar(): void {
    this.sidebarCollapsed = !this.sidebarCollapsed;
  }

getMenuLink(objectName: string): string {
  switch (objectName.toLowerCase()) {
    case 'consolidate policy':  return '/consolidate-policy';
    case 'report':              return '/report';
    case 'new dashboard':       return '/dashboard';
    default:                    return '/dashboard';
  }
}
  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}