import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  canActivate(): boolean {
    console.log('🔐 AuthGuard: check login status...');  // 👈 LOG
    
    const loggedIn = this.authService.isLoggedIn();
    console.log('✅ isLoggedIn() return:', loggedIn);  // 👈 LOG
    
    if (loggedIn) {
      return true;
    } else {
      console.log('🚫 Redirect to /login');  // 👈 LOG
      this.router.navigate(['/login']);
      return false;
    }
  }
}
