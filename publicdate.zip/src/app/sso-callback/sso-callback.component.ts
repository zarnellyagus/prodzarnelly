import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SsoService } from '../services/sso.service';

@Component({
  selector: 'app-sso-callback',
  standalone: false,
  template: `
    <div class="sso-callback-wrapper">
      <div class="sso-callback-box">
        <div class="spinner-border text-primary mb-3" role="status"></div>
        <p>{{ message }}</p>
        <p *ngIf="errorDetail" class="text-danger small">{{ errorDetail }}</p>
      </div>
    </div>
  `,
  styles: [`
    .sso-callback-wrapper {
      display: flex; justify-content: center; align-items: center;
      height: 100vh; background: #f0f2f5;
    }
    .sso-callback-box {
      text-align: center; padding: 40px; background: white;
      border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    }
  `]
})
export class SsoCallbackComponent implements OnInit {
  message = 'Memproses SSO login...';
  errorDetail = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private ssoService: SsoService
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      const token = params['sso_token'];
      const error = params['error'];
      const companyID = params['companyID'];

      if (error) {
        this.message = 'SSO login gagal.';
        this.errorDetail = decodeURIComponent(error);
        setTimeout(() => this.router.navigate(['/login']), 3000);
        return;
      }

      if (token) {
        this.message = 'Verifikasi token...';
        this.ssoService.handleSsoCallback(token, companyID).subscribe({
          next: (response) => {
            if (response.success) {
              localStorage.setItem('auth_token', response.token);
              localStorage.setItem('user_info', JSON.stringify({
                username: response.username,
                companyID: response.companyID
              }));
              const returnPath = sessionStorage.getItem('sso_return_path') || '/dashboard';
              sessionStorage.removeItem('sso_return_path');
              this.router.navigate([returnPath]);
            } else {
              this.message = 'SSO login ditolak.';
              this.errorDetail = response.message || '';
              setTimeout(() => this.router.navigate(['/login']), 3000);
            }
          },
          error: () => {
            this.message = 'Terjadi kesalahan server.';
            setTimeout(() => this.router.navigate(['/login']), 3000);
          }
        });
      } else {
        // Tidak ada token, kembali ke login
        this.router.navigate(['/login']);
      }
    });
  }
}