import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule, DatePipe } from '@angular/common';
import { AppRoutingModule } from './app-routing.module';

// Non-standalone components (standalone: false) — wajib di declarations
import { AppComponent } from './app.component';
import { SsoCallbackComponent } from './sso-callback/sso-callback.component';

// Services & Guards
import { AuthService } from './services/auth.service';
import { PolicyService } from './services/policy.service';
import { AuthGuard } from './guards/auth.guard';

// ─── Tambahkan service baru di sini jika ada ────────────────────
import { ReportService } from './services/report.service';
import { ExcelExportService } from './services/excel-export.service';

@NgModule({
  declarations: [
    // HANYA component dengan standalone: false
    AppComponent,
    SsoCallbackComponent
    // LoginComponent        ← JANGAN masukkan, sudah standalone
    // DashboardComponent    ← JANGAN masukkan, sudah standalone
    // ConsolidatePolicyComponent ← JANGAN masukkan, sudah standalone
    // ReportComponent       ← JANGAN masukkan, sudah standalone
  ],
  imports: [
    BrowserModule,          // wajib untuk bootstrap browser
    CommonModule,           // *ngIf, *ngFor, pipes
    ReactiveFormsModule,    // FormGroup, FormControl
    FormsModule,            // [(ngModel)]
    HttpClientModule,       // HttpClient
    AppRoutingModule        // routing — standalone components dimuat via loadComponent
  ],
  providers: [
    AuthService,
    PolicyService,
    AuthGuard,
    DatePipe,
    ReportService,          // ← tambahkan jika belum providedIn: 'root'
    ExcelExportService      // ← tambahkan jika belum providedIn: 'root'
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}