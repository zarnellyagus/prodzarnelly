import { Routes } from '@angular/router';
import { AuthGuard } from './guards/auth.guard';

export const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  {
    path: 'login',
    loadComponent: () => import('./login/login.component').then(c => c.LoginComponent)
  },
  {
    path: '',                          // ← path kosong, bukan 'dashboard'
    loadComponent: () =>
      import('./dashboard/dashboard.component').then(c => c.DashboardComponent),
    canActivate: [AuthGuard],
    children: [
      {
        path: 'dashboard',             // → /dashboard
        loadComponent: () =>
          import('./new-dashboard/new-dashboard.component').then(c => c.NewDashboardComponent)
      },
      {
        path: 'consolidate-policy',    // → /consolidate-policy
        loadComponent: () =>
          import('./consolidate-policy/consolidate-policy.component').then(c => c.ConsolidatePolicyComponent)
      },  {
        path: 'report',                // → /report
        loadComponent: () =>
          import('./report/report.component').then(c => c.ReportComponent)
      },
      
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' }
    ]
  },
  { path: '**', redirectTo: '/login' }
];