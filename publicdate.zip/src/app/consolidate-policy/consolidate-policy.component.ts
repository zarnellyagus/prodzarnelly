// consolidate-policy/consolidate-policy.component.ts
import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil, finalize } from 'rxjs/operators';

import {
  PolicyService,
  PagedResult,
  ConsolidatePolicy
} from '../services/policy.service';

@Component({
  selector: 'app-consolidate-policy',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterModule
    // ← JANGAN import PolicyDetailComponent di sini
    // ← gunakan router navigate, bukan embed component
  ],
  templateUrl: './consolidate-policy.component.html',
  styleUrls: ['./consolidate-policy.component.scss']
})
export class ConsolidatePolicyComponent implements OnInit, OnDestroy {

  // ── Filter ────────────────────────────────────────────────────
  filterPolicyId = '';
  filterAppNo    = '';

  // ── Data ──────────────────────────────────────────────────────
  policies:     ConsolidatePolicy[] = [];
  totalRecords  = 0;
  totalPages    = 0;
  pageNumber    = 1;
  pageSize      = 10;
  pageSizeOptions = [10, 25, 50, 100];

  // ── State ─────────────────────────────────────────────────────
  isLoading  = false;
  errorMsg   = '';

  private destroy$ = new Subject<void>();

  constructor(
    private policyService: PolicyService,
    private router:        Router
  ) {}

  ngOnInit(): void {
    this.loadPolicies();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  // ─────────────────────────────────────────────────────────────
  // Load Data
  // ─────────────────────────────────────────────────────────────
  loadPolicies(): void {
    this.isLoading = true;
    this.errorMsg  = '';

    this.policyService.getConsolidatePolicies(   // ← fix: pakai nama yang benar
      this.filterPolicyId || undefined,
      this.filterAppNo    || undefined,
      this.pageNumber,
      this.pageSize
    )
    .pipe(
      takeUntil(this.destroy$),
      finalize(() => this.isLoading = false)
    )
    .subscribe({
      next: (response: PagedResult<ConsolidatePolicy>) => {  // ← fix: tambah type
        this.policies     = response.data;
        this.totalRecords = response.totalRecords;
        this.totalPages   = response.totalPages;
      },
      error: (err: any) => {                                 // ← fix: tambah type
        this.errorMsg = err?.error?.message ?? 'Gagal memuat data.';
        console.error('Load policies error:', err);
      }
    });
  }

  // ─────────────────────────────────────────────────────────────
  // Search & Reset
  // ─────────────────────────────────────────────────────────────
  onSearch(): void {
    this.pageNumber = 1;
    this.loadPolicies();
  }

  onReset(): void {
    this.filterPolicyId = '';
    this.filterAppNo    = '';
    this.pageNumber     = 1;
    this.loadPolicies();
  }

  // ─────────────────────────────────────────────────────────────
  // Navigate ke Detail (bukan embed component)
  // ─────────────────────────────────────────────────────────────
  onViewDetail(policyId: string): void {
    this.router.navigate(['/policy-detail', policyId]);
  }

  // ─────────────────────────────────────────────────────────────
  // Pagination
  // ─────────────────────────────────────────────────────────────
  onPageChange(page: number): void {
    if (page < 1 || page > this.totalPages) return;
    this.pageNumber = page;
    this.loadPolicies();
  }

  onPageSizeChange(): void {
    this.pageNumber = 1;
    this.loadPolicies();
  }

  getPageNumbers(): number[] {
    const pages: number[] = [];
    const start = Math.max(1, this.pageNumber - 2);
    const end   = Math.min(this.totalPages, this.pageNumber + 2);
    for (let i = start; i <= end; i++) pages.push(i);
    return pages;
  }

  getStartRecord(): number {
    return this.totalRecords === 0
      ? 0
      : (this.pageNumber - 1) * this.pageSize + 1;
  }

  getEndRecord(): number {
    return Math.min(this.pageNumber * this.pageSize, this.totalRecords);
  }

  formatDate(value: string | null | undefined): string {
    if (!value) return '-';
    try {
      return new Date(value).toLocaleDateString('id-ID', {
        day: '2-digit', month: 'short', year: 'numeric'
      });
    } catch {
      return value ?? '-';
    }
  }
}