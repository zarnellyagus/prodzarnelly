import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';

import { AuthService, Company, LoginRequest } from '../services/auth.service';
import { SsoService } from '../services/sso.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule
  ],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  companies: Company[] = [];
  errorMessage: string = '';
  isLoading: boolean = false;
  isSsoLoading: boolean = false;

  constructor(
    private formBuilder: FormBuilder,
    private authService: AuthService,
    private ssoService: SsoService,
    private router: Router
  ) {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(3)]],
      companyID: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.loadCompanies();
    this.checkSsoCallback();

    if (this.authService.isLoggedIn()) {
      this.router.navigate(['/dashboard']);
    }
  }

  loadCompanies(): void {
    this.authService.getCompanies().subscribe({
      next: (companies) => {
        this.companies = companies;
      },
      error: () => {
        this.errorMessage = 'Gagal memuat daftar company';
      }
    });
  }

  checkSsoCallback(): void {
    const urlParams = new URLSearchParams(window.location.search);
    const ssoToken = urlParams.get('sso_token');
    const error = urlParams.get('error');

    if (error) {
      this.errorMessage = `SSO Error: ${decodeURIComponent(error)}`;
      window.history.replaceState({}, document.title, window.location.pathname);
      return;
    }

    if (ssoToken) {
      this.isSsoLoading = true;

      this.ssoService.handleSsoCallback(ssoToken).subscribe({
        next: (response) => {
          this.isSsoLoading = false;

          if (response.success) {
            localStorage.setItem('auth_token', response.token);
            localStorage.setItem('user_info', JSON.stringify({
              username: response.username,
              companyID: response.companyID
            }));

            const returnPath = sessionStorage.getItem('sso_return_path') || '/dashboard';
            sessionStorage.removeItem('sso_return_path');
            this.router.navigate([returnPath]);
          } else {
            this.errorMessage = response.message || 'SSO login gagal';
          }

          window.history.replaceState({}, document.title, window.location.pathname);
        },
        error: () => {
          this.isSsoLoading = false;
          this.errorMessage = 'Terjadi kesalahan saat memproses SSO. Silakan coba lagi.';
          window.history.replaceState({}, document.title, window.location.pathname);
        }
      });
    }
  }

  onSsoLogin(): void {
    this.isSsoLoading = true;
    this.errorMessage = '';

    try {
      this.ssoService.initiateSSO();
    } catch {
      this.isSsoLoading = false;
      this.errorMessage = 'Gagal memulai SSO. Silakan coba lagi.';
    }
  }

  onLogin(): void {
    if (this.loginForm.valid) {
      this.isLoading = true;
      this.errorMessage = '';

      const credentials: LoginRequest = this.loginForm.value;

      this.authService.login(credentials).subscribe({
        next: (response) => {
          this.isLoading = false;

          if (response.success) {
            this.router.navigate(['/dashboard']);
          } else {
            this.errorMessage = response.message;
          }
        },
        error: () => {
          this.isLoading = false;
          this.errorMessage = 'Terjadi kesalahan saat login. Silakan coba lagi.';
        }
      });
    } else {
      this.markFormGroupTouched();
    }
  }

  private markFormGroupTouched(): void {
    Object.keys(this.loginForm.controls).forEach(key => {
      this.loginForm.get(key)?.markAsTouched();
    });
  }
}