// policy-detail/policy-detail.component.ts
import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { Subject, forkJoin } from 'rxjs';
import { takeUntil, finalize } from 'rxjs/operators';

import {
  PolicyService,
  PolicyDetail,
  EPolicyStatus,
  PolicySummary,
  ReturnSms
} from '../services/policy.service';

@Component({
  selector: 'app-policy-detail',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './policy-detail.component.html',
  styleUrls: ['./policy-detail.component.scss']
})
export class PolicyDetailComponent implements OnInit, OnDestroy {

  policyId = '';

  // ── Data ──────────────────────────────────────────────────────
  policyInfo:             PolicyDetail   | null = null;
  ePolicies:              EPolicyStatus[]       = [];
  policySummaries:        PolicySummary[]       = [];
  returnSmsList:          ReturnSms[]           = [];
  resendEPolicies:        EPolicyStatus[]       = [];
  resendPolicySummaries:  PolicySummary[]       = [];

  // ── Loading States ────────────────────────────────────────────
  policyInfoLoading          = false;
  ePolicyLoading             = false;
  policySummaryLoading       = false;
  returnSmsLoading           = false;
  resendEPolicyLoading       = false;
  resendPolicySummaryLoading = false;

  // ── Active Tab ────────────────────────────────────────────────
  activeTab: 'policy-info' | 'summary-info' | 'resend-info' = 'policy-info';

  private destroy$ = new Subject<void>();

  constructor(
    private route:         ActivatedRoute,
    private router:        Router,
    private policyService: PolicyService
  ) {}

  ngOnInit(): void {
    this.policyId = this.route.snapshot.paramMap.get('policyId') ?? '';

    if (!this.policyId) {
      this.router.navigate(['/consolidate-policy']);
      return;
    }

    this.loadAllData();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  // ─────────────────────────────────────────────────────────────
  // Load All Data (parallel)
  // ─────────────────────────────────────────────────────────────
  private loadAllData(): void {
    this.loadPolicyDetail();
    this.loadSummaryTab();
    this.loadResendTab();
  }

  // ── Policy Detail ─────────────────────────────────────────────
  private loadPolicyDetail(): void {
    this.policyInfoLoading = true;
    this.policyService.getPolicyDetail(this.policyId)
      .pipe(
        takeUntil(this.destroy$),
        finalize(() => this.policyInfoLoading = false)
      )
      .subscribe({
        next:  (data) => this.policyInfo = data,
        error: (err)  => console.error('PolicyDetail error', err)
      });
  }

  // ── Summary Tab (E-Policy + Summary + Return SMS parallel) ────
  private loadSummaryTab(): void {
    this.ePolicyLoading       = true;
    this.policySummaryLoading = true;
    this.returnSmsLoading     = true;

    forkJoin({
      ePolicies:   this.policyService.getEPolicyStatus(this.policyId),
      summaries:   this.policyService.getPolicySummary(this.policyId),
      returnSms:   this.policyService.getReturnSms(this.policyId)
    })
    .pipe(takeUntil(this.destroy$))
    .subscribe({
      next: ({ ePolicies, summaries, returnSms }) => {
        this.ePolicies        = ePolicies;
        this.policySummaries  = summaries;
        this.returnSmsList    = returnSms;
      },
      error: (err) => console.error('SummaryTab error', err),
      complete: () => {
        this.ePolicyLoading       = false;
        this.policySummaryLoading = false;
        this.returnSmsLoading     = false;
      }
    });
  }

  // ── Resend Tab (Resend E-Policy + Resend Summary parallel) ────
  private loadResendTab(): void {
    this.resendEPolicyLoading       = true;
    this.resendPolicySummaryLoading = true;

    forkJoin({
      resendEPolicies:  this.policyService.getResendEPolicy(this.policyId),
      resendSummaries:  this.policyService.getResendPolicySummary(this.policyId)
    })
    .pipe(takeUntil(this.destroy$))
    .subscribe({
      next: ({ resendEPolicies, resendSummaries }) => {
        this.resendEPolicies       = resendEPolicies;
        this.resendPolicySummaries = resendSummaries;
      },
      error: (err) => console.error('ResendTab error', err),
      complete: () => {
        this.resendEPolicyLoading       = false;
        this.resendPolicySummaryLoading = false;
      }
    });
  }

  // ─────────────────────────────────────────────────────────────
  // Tab Control
  // ─────────────────────────────────────────────────────────────
  setTab(tab: 'policy-info' | 'summary-info' | 'resend-info'): void {
    this.activeTab = tab;
  }

  // ─────────────────────────────────────────────────────────────
  // Helper Methods
  // ─────────────────────────────────────────────────────────────
  getPolicyInfoValue(key: keyof PolicyDetail): string {
    if (!this.policyInfo) return '-';
    return (this.policyInfo[key] as string) || '-';
  }

  getPolicyInfoDateValue(key: keyof PolicyDetail): string {
    if (!this.policyInfo) return '-';
    const val = this.policyInfo[key];
    return val ? this.formatDate(val as string) : '-';
  }

  getEPolicyValue(ep: EPolicyStatus, key: keyof EPolicyStatus): string {
    return (ep[key] as string) || '-';
  }

  getEPolicyDateValue(ep: EPolicyStatus, key: keyof EPolicyStatus): string {
    const val = ep[key];
    return val ? this.formatDate(val as string) : '-';
  }

  formatDate(value: string | null | undefined): string {
    if (!value) return '-';
    try {
      const d = new Date(value);
      if (isNaN(d.getTime())) return value;
      return d.toLocaleDateString('id-ID', {
        day:   '2-digit',
        month: 'short',
        year:  'numeric'
      });
    } catch {
      return value ?? '-';
    }
  }

  getSourceBadgeClass(source: string): string {
    switch (source?.toLowerCase()) {
      case 'email': return 'badge--info';
      case 'wa':    return 'badge--success';
      case 'sms':   return 'badge--warning';
      default:      return 'badge--secondary';
    }
  }

  getSourceIcon(source: string): string {
    switch (source?.toLowerCase()) {
      case 'email': return 'fa-envelope';
      case 'wa':    return 'fa-whatsapp';
      case 'sms':   return 'fa-sms';
      default:      return 'fa-paper-plane';
    }
  }

  getStatusBorderClass(status: string): string {
    switch (status?.toUpperCase()) {
      case 'DELIVERED':  return 'pd-card--delivered';
      case 'ON PROCESS': return 'pd-card--process';
      case 'RETURNED':   return 'pd-card--returned';
      default:           return 'pd-card--secondary';
    }
  }

  getStatusBadgeClass(status: string): string {
    switch (status?.toUpperCase()) {
      case 'DELIVERED':  return 'badge--success';
      case 'ON PROCESS': return 'badge--warning';
      case 'RETURNED':   return 'badge--danger';
      default:           return 'badge--secondary';
    }
  }

  goBack(): void {
    this.router.navigate(['/consolidate-policy']);
  }
}