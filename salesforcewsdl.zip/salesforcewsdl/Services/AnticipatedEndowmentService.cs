﻿using salesforcewsdl.Models;
using System.Globalization;
using System.ServiceModel;
using TXLifeProxy; // ← namespace dari Connected Service

namespace salesforcewsdl.Services
{
    public class AnticipatedEndowmentService
    {
        private readonly IConfiguration _config;

        public AnticipatedEndowmentService(IConfiguration config)
        {
            _config = config;
        }

        public async Task<List<AnticipatedEndowmentResponse>> GetAsync(string policyId)
        {
            string url = _config["TXLife:ServiceUrl"]
                         ?? "http://10.154.5.45:8093/TXLife/services/TXLife";

            // =============================================
            // Konfigurasi Binding & Endpoint dari proxy
            // =============================================
            var binding = new BasicHttpBinding
            {
                MaxReceivedMessageSize = 10_000_000,
                SendTimeout = TimeSpan.FromSeconds(30),
                ReceiveTimeout = TimeSpan.FromSeconds(30),
                Security = new BasicHttpSecurity
                {
                    Mode = BasicHttpSecurityMode.None
                }
            };

            var endpoint = new EndpointAddress(url);

            // TXLifePortTypeClient → nama class dari Reference.cs
            using var client = new TXLifePortTypeClient(binding, endpoint);

            // =============================================
            // Build Request menggunakan proxy class
            // =============================================
            var txLifeReq = new TXLife1
            {
                SignonCompany = "CP",
                UserAuthRequest = new UserAuthRequest
                {
                    UserLoginName = _config["TXLife:Username"] ?? "fi80w",
                    UserPswd = new UserPswd
                    {
                        CryptType = "NONE",
                        Pswd = _config["TXLife:Password"] ?? "fi80w"
                    },
                    UserCold = _config["TXLife:CompanyCode"] ?? "CP"
                },
                TXLifeRequest = new TXLifeRequest
                {
                    TransRefGUID = Guid.NewGuid().ToString(),
                    TransType = new TransType { tc = "228" },
                    TransExeDate = DateTime.Today.ToString("yyyy-MM-dd"),
                    TransExeTime = DateTime.Now.ToString("HH:mm:ss"),
                    OLifE = new OLifE
                    {
                        InquiryAnticipatedEndowmentData =
                            new InquiryAnticipatedEndowmentData
                            {
                                MirCommonFields = new MirCommonFields
                                {
                                    MirDvEffDt = string.Empty,
                                    MirCvgNum = "01",
                                    MirPolPayoNum = "00001"
                                },
                                MirPolId = new MirPolId
                                {
                                    MirPolIdBase = policyId,
                                    MirPolIdSfx = string.Empty
                                }
                            }
                    }
                }
            };

            // =============================================
            // Panggil SOAP method via proxy
            // =============================================
            TXLifeResponse response = await client.TXLifeAsync(txLifeReq);

            return MapToModel(policyId, response);
        }

        // =============================================
        // MAP RESPONSE → Model
        // =============================================
        private List<AnticipatedEndowmentResponse> MapToModel(
            string policyId, TXLifeResponse response)
        {
            var results = new List<AnticipatedEndowmentResponse>();

            var endowData = response?.OLifE?.InquiryAnticipatedEndowmentData;
            if (endowData == null) return results;

            var common = endowData.MirCommonFields;
            var valuotr = endowData.MirValuotrFields;
            var valuln = endowData.MirValulnFields;

            var payoMethods = endowData.MirCdiPayoMthdCdG?
                              .MirCdiPayoMthdCdT ?? Array.Empty<string>();

            var payoDates = endowData.MirDvXpctPayoDtG?
                              .MirDvXpctPayoDtT ?? Array.Empty<string>();

            // ContractualPayoutInformation
            var contractual = new ContractualPayoutInformation
            {
                PolicyID = policyId,
                PayoutMethod = payoMethods.FirstOrDefault() ?? string.Empty,
                PayoutNumber = int.TryParse(common?.MirPolPayoNum, out var pn) ? pn : 0,
                NextPayoutDate = ParseDate(common?.MirPolPayoNxtDt),
                LastPayoutDate = ParseDate(common?.MirCdaEffDt),
                LastPayoutAmount = ParseDecimal(common?.MirLastPayoAmt),
                TotalPayoutAmount = ParseDecimal(common?.MirPolPayoAmt),
                IssueDate = ParseDate(common?.MirPolPayoEffDt)
            };

            // List<PayoutDateInformation>
            var payoutDateList = payoDates
                .Select((date, i) => new PayoutDateInformation
                {
                    PolicyID = policyId,
                    PayoutDate = ParseDate(date),
                    PayoutAmount = ParseDecimal(common?.MirPolPayoAmt),
                    PayoutStatus = string.Empty,
                    SequenceNumber = i + 1
                }).ToList();

            // AEFundInformation
            var aeFundInfo = new AEFundInformation
            {
                PolicyID = policyId,
                AEFund = valuotr?.MirPolAeAmt ?? string.Empty,
                AEFundInterest = valuotr?.MirPolAeIntAmt ?? string.Empty,
                LastWithdrawalDate = null,
                LoanBalance = ParseDecimal(valuln?.MirDvLoanRepayAmt),
                PlanName = common?.MirDvFndDescTxt ?? string.Empty,
                LastWithdrawalAmount = ParseDecimal(common?.MirLastAeWthdrAmt)
            };

            results.Add(new AnticipatedEndowmentResponse
            {
                ContractualPayoutInfo = contractual,
                PayoutDates = payoutDateList,
                AEFundInfo = aeFundInfo
            });

            return results;
        }

        private static decimal ParseDecimal(string? value) =>
            decimal.TryParse(value, NumberStyles.Any,
                CultureInfo.InvariantCulture, out var v) ? v : 0m;

        private static DateTime? ParseDate(string? value)
        {
            if (string.IsNullOrWhiteSpace(value)) return null;
            return DateTime.TryParse(value,
                CultureInfo.InvariantCulture,
                DateTimeStyles.None, out var d) ? d : null;
        }
    }
}
