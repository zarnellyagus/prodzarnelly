﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using salesforcewsdl.Models;

using salesforcewsdl.Services;

namespace Salesforce_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AnticipatedEndowmentController : ControllerBase
    {
        private readonly AnticipatedEndowmentService _service;

        public AnticipatedEndowmentController(AnticipatedEndowmentService service)
        {
            _service = service;
        }

        [HttpPost]
        [ProducesResponseType(typeof(List<AnticipatedEndowmentResponse>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(string), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(string), StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<List<AnticipatedEndowmentResponse>>> SendSoapRequestAsync(
            [FromQuery] string Policyid)
        {
            if (string.IsNullOrWhiteSpace(Policyid))
                return BadRequest("PolicyID tidak boleh kosong.");

            try
            {
                var results = await _service.GetAsync(Policyid);

                if (results == null || results.Count == 0)
                    return NotFound(
                        $"Data untuk PolicyID '{Policyid}' tidak ditemukan.");

                return Ok(results);
            }
            catch (EndpointNotFoundException ex)
            {
                return StatusCode(500,
                    $"Gagal terhubung ke TXLife Webservice: {ex.Message}");
            }
            catch (CommunicationException ex)
            {
                return StatusCode(500,
                    $"Komunikasi TXLife gagal: {ex.Message}");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error: {ex.Message}");
            }
        }
    }
}