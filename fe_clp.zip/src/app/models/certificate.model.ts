export interface Certificate {
  memberID: string;
  companyID: string;
  policyID: string;
  certificateID: string;
  certificateStatus: string;
  certificateStatusName: string;
  underwritingStatus: string;
  underwritingStatusName: string;
  hasAdminPending: boolean;
  insuredID: string;
  insuredName: string;
  insuredDOB: string;
  insuredSex: string;
  insuredAge: number;
  applicationNo: string;
  agreementNo: string;
  effectiveDate: string;
  inforceDate: string;
  terminateDate: string;
  monthlyInstallment: number;
  totalSAR: number;
  productPackageName: string;
  productTypeName: string;
  policyOwnerName: string;
  pendingItem: string;
  progressStatusName: string;
  partnerName: string;
  mobileNumber: string;
  createdDate: string;
}

export interface CertificateFilter {
  memberID?: string;
  companyID?: string;
  policyID?: string;
  certificateID?: string;
  certificateStatus?: string;
  pageNumber: number;
  pageSize: number;
  sortColumn: string;
  sortDirection: string;
}

export interface PagedResult<T> {
  data: T[];
  totalRecords: number;
  pageNumber: number;
  pageSize: number;
  totalPages: number;
}