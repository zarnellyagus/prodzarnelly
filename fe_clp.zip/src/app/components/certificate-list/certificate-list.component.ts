import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { CommonModule, DatePipe, CurrencyPipe } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CertificateService } from '../../services/certificate.service';
import { Certificate, CertificateFilter, PagedResult } from '../../models/certificate.model';

@Component({
  selector: 'app-certificate-list',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule, DatePipe, CurrencyPipe],
  templateUrl: './certificate-list.component.html',
  styleUrl: './certificate-list.component.css'
})
export class CertificateListComponent implements OnInit {
  private svc = inject(CertificateService);
  private fb  = inject(FormBuilder);

  // Signals
  certificates  = signal<Certificate[]>([]);
  totalRecords  = signal(0);
  totalPages    = signal(0);
  isLoading     = signal(false);
  errorMessage  = signal('');
  selectedItem  = signal<Certificate | null>(null);

  // Pagination & sort state
  pageNumber   = signal(1);
  pageSize     = signal(20);
  sortColumn   = signal('CreatedDate');
  sortDir      = signal<'ASC' | 'DESC'>('DESC');

  // Computed pagination info
  startRow = computed(() => (this.pageNumber() - 1) * this.pageSize() + 1);
  endRow   = computed(() => Math.min(this.pageNumber() * this.pageSize(), this.totalRecords()));
  pages    = computed(() => Array.from({ length: this.totalPages() }, (_, i) => i + 1));

  filterForm: FormGroup = this.fb.group({
    memberID:          [''],
    companyID:         [''],
    policyID:          [''],
    certificateID:     [''],
    certificateStatus: [''],
  });

  statusOptions = [
    { code: '', label: 'All Status' },
    { code: 'ACT', label: 'Active' },
    { code: 'LAP', label: 'Lapsed' },
    { code: 'TRM', label: 'Terminated' },
    { code: 'PND', label: 'Pending' },
  ];

  ngOnInit() { this.loadData(); }

  loadData() {
    this.isLoading.set(true);
    this.errorMessage.set('');
    const f = this.filterForm.value;

    const filter: CertificateFilter = {
      ...f,
      pageNumber:    this.pageNumber(),
      pageSize:      this.pageSize(),
      sortColumn:    this.sortColumn(),
      sortDirection: this.sortDir(),
    };

    this.svc.getList(filter).subscribe({
      next: (res) => {
        this.certificates.set(res.data);
        this.totalRecords.set(res.totalRecords);
        this.totalPages.set(res.totalPages);
        this.isLoading.set(false);
      },
      error: (err) => {
        this.errorMessage.set(err?.error?.message ?? 'Failed to load data');
        this.isLoading.set(false);
      }
    });
  }

  search() {
    this.pageNumber.set(1);
    this.loadData();
  }

  resetFilter() {
    this.filterForm.reset({ memberID:'', companyID:'', policyID:'', certificateID:'', certificateStatus:'' });
    this.pageNumber.set(1);
    this.loadData();
  }

  sort(col: string) {
    if (this.sortColumn() === col) {
      this.sortDir.set(this.sortDir() === 'ASC' ? 'DESC' : 'ASC');
    } else {
      this.sortColumn.set(col);
      this.sortDir.set('ASC');
    }
    this.loadData();
  }

  sortIcon(col: string): string {
    if (this.sortColumn() !== col) return '↕';
    return this.sortDir() === 'ASC' ? '↑' : '↓';
  }

  goToPage(page: number) {
    if (page < 1 || page > this.totalPages()) return;
    this.pageNumber.set(page);
    this.loadData();
  }

  openDetail(item: Certificate) { this.selectedItem.set(item); }
  closeDetail() { this.selectedItem.set(null); }

  getStatusClass(status: string): string {
    const map: Record<string, string> = {
      ACT: 'badge-success', LAP: 'badge-warning',
      TRM: 'badge-danger',  PND: 'badge-info'
    };
    return map[status] ?? 'badge-secondary';
  }
}