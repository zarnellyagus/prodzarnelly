﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Salesforce_API.Models;
using Salesforce_API.Service;
using System.Globalization;
using System.Xml;
using System.Xml.Linq;

namespace Salesforce_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValueInformationController : ControllerBase
    {
        private readonly Requestsoap _requestsoap;

        public ValueInformationController(Requestsoap requestsoap)
        {
            _requestsoap = requestsoap;
        }

        [HttpPost]
        [ProducesResponseType(typeof(ApiSuccessResponse<ValueInformationResponse>), 200)]
        [ProducesResponseType(typeof(ApiErrorResponse), 400)]
        [ProducesResponseType(typeof(ApiErrorResponse), 404)]
        [ProducesResponseType(typeof(ApiErrorResponse), 500)]
        public async Task<ActionResult<ApiSuccessResponse<ValueInformationResponse>>> SendSoapRequestAsync(
            [FromBody] ValueInformationRequest request)
        {
            // ============================================================
            // VALIDASI REQUEST
            // ============================================================
            if (request == null || string.IsNullOrWhiteSpace(request.PolicyId))
            {
                return BadRequest(new ApiErrorResponse
                {
                    StatusCode = 400,
                    Message = "Bad Request",
                    Detail = "PolicyId tidak boleh kosong.",
                    Timestamp = DateTime.Now
                });
            }

            string policyId = request.PolicyId.Trim();
            string datenow = DateTime.Today
                                .ToString("ddMMMyyyy", CultureInfo.InvariantCulture)
                                .ToUpper();
            string url = "http://10.154.5.45:8093/TXLife/services/TXLife";

            XNamespace soapNs = "http://schemas.xmlsoap.org/soap/envelope/";
            XNamespace webNs = "http://schema/webservices.elink.solcorp.com";
            XNamespace acordNs = "http://ACORD.org/Standards/Life/2";
            XNamespace xsiNs = "http://www.w3.org/2001/XMLSchema-instance";
            XNamespace xsdNs = "http://www.w3.org/2001/XMLSchema";

            try
            {
                // ============================================================
                // HELPER — Build common SOAP envelope
                // ============================================================
                XElement BuildEnvelope(string transType, XElement olifeBody) =>
                    new XElement(soapNs + "Envelope",
                        new XAttribute(XNamespace.Xmlns + "soapenv", soapNs),
                        new XAttribute(XNamespace.Xmlns + "web", webNs),
                        new XElement(soapNs + "Header"),
                        new XElement(soapNs + "Body",
                            new XElement(acordNs + "TXLife",
                                new XAttribute(XNamespace.Xmlns + "xsi", xsiNs),
                                new XAttribute(XNamespace.Xmlns + "xsd", xsdNs),
                                new XAttribute(xsiNs + "schemaLocation",
                                    "http://ACORD.org/Standards/Life/2 ../xsd/TXLife2.9.00.xsd"),
                                new XElement(acordNs + "UserAuthRequest",
                                    new XElement(acordNs + "UserLoginName", "fi80w"),
                                    new XElement(acordNs + "UserPswd",
                                        new XElement(acordNs + "CryptType", "NONE"),
                                        new XElement(acordNs + "Pswd", "fi80w")),
                                    new XElement(acordNs + "UserCoId", "CP")),
                                new XElement(acordNs + "TXLifeRequest",
                                    new XElement(acordNs + "TransRefGUID", ""),
                                    new XElement(acordNs + "TransType",
                                        new XAttribute("tc", transType), ""),
                                    new XElement(acordNs + "TransExeDate",
                                        DateTime.Today.ToString("ddMMMyyyy",
                                            CultureInfo.InvariantCulture).ToUpper()),
                                    new XElement(acordNs + "TransExeTime",
                                        DateTime.Now.ToString("HH:mm:ss")),
                                    olifeBody))));

                // ============================================================
                // 1. InquiryFundValues
                // ============================================================
                var xmlFV = BuildEnvelope("InquiryFundValues",
                    new XElement(acordNs + "OLiFE",
                        new XElement(acordNs + "InquiryFundValuesData",
                            new XElement(acordNs + "MirPolIdBase", policyId))));

                // ============================================================
                // 2. InquiryPolicyValues
                // ============================================================
                var xmlPV = BuildEnvelope("InquiryPolicyValues",
                    new XElement(acordNs + "OLiFE",
                        new XElement(acordNs + "InquiryPolicyValuesData",
                            new XElement(acordNs + "MirCommonFields",
                                new XElement(acordNs + "MirDvEffDt", ""),
                                new XElement(acordNs + "MirPolId",
                                    new XElement(acordNs + "MirPolIdBase", policyId),
                                    new XElement(acordNs + "MirPolIdSfx", ""))))));

                // ============================================================
                // 3. InquirySummary
                // ============================================================
                var xmlSMR = BuildEnvelope("InquirySummary",
                    new XElement(acordNs + "OLiFE",
                        new XElement(acordNs + "InquirySummaryData",
                            new XElement(acordNs + "MirCommonFields",
                                new XElement(acordNs + "MirDvEffDt", datenow),
                                new XElement(acordNs + "MirPolId",
                                    new XElement(acordNs + "MirPolIdBase", policyId),
                                    new XElement(acordNs + "MirPolIdSfx", "")),
                                new XElement(acordNs + "MirCvgNum", "")))));

                // ============================================================
                // 4. FundInquiryAccumulationUnits
                // ============================================================
                var xmlFA = BuildEnvelope("FundInquiryAccumulationUnits",
                    new XElement(acordNs + "OLIFEC",
                        new XElement(acordNs + "FundInquiryAccumulationUnitsData",
                            new XElement(acordNs + "MirPolId",
                                new XElement(acordNs + "MirCvgNum", "01"),
                                new XElement(acordNs + "MirPolIdBase", policyId),
                                new XElement(acordNs + "MirPolIdSfx", ""),
                                new XElement(acordNs + "MirCiaEffDt", datenow),
                                new XElement(acordNs + "MirCiaSeqNum", "999"),
                                new XElement(acordNs + "MirCiaTypCd", "")))));

                // ============================================================
                // 5. FundInquiryActivity
                // ============================================================
                var xmlFVL = BuildEnvelope("FundInquiryActivity",
                    new XElement(acordNs + "OLife",
                        new XElement(acordNs + "FundInquiryActivityData",
                            new XElement(acordNs + "MirPolId",
                                new XElement(acordNs + "MirCvgNum", "01"),
                                new XElement(acordNs + "MirPolIdBase", policyId),
                                new XElement(acordNs + "MirPolIdSfx", ""),
                                new XElement(acordNs + "MirCiaEffDt", datenow),
                                new XElement(acordNs + "MirCiaSeqNum", "999"),
                                new XElement(acordNs + "MirCiaTypCd", "")))));

                // ============================================================
                // KIRIM SEMUA SOAP REQUEST SECARA PARALEL
                // ============================================================
                var tasks = await Task.WhenAll(
                    _requestsoap.PostSOAPRequestAsync(url, xmlFV.ToString()),
                    _requestsoap.PostSOAPRequestAsync(url, xmlPV.ToString()),
                    _requestsoap.PostSOAPRequestAsync(url, xmlSMR.ToString()),
                    _requestsoap.PostSOAPRequestAsync(url, xmlFA.ToString()),
                    _requestsoap.PostSOAPRequestAsync(url, xmlFVL.ToString())
                );

                string responseStateFV = tasks[0];
                string responseStatePV = tasks[1];
                string responseStateSMR = tasks[2];
                string responseStateFA = tasks[3];
                string responseStateFVL = tasks[4];

                // ============================================================
                // VALIDASI SEMUA RESPONSE TIDAK KOSONG
                // ============================================================
                if (string.IsNullOrWhiteSpace(responseStateFV) ||
                    string.IsNullOrWhiteSpace(responseStatePV) ||
                    string.IsNullOrWhiteSpace(responseStateSMR) ||
                    string.IsNullOrWhiteSpace(responseStateFA) ||
                    string.IsNullOrWhiteSpace(responseStateFVL))
                {
                    return Ok(BuildEmptySuccessResponse(policyId));
                }

                // ============================================================
                // PARSE XML HELPER
                // ============================================================
                (XmlDocument doc, XmlNamespaceManager ns) ParseXml(string raw)
                {
                    string fmt = XDocument.Parse(raw).ToString();
                    var doc = new XmlDocument();
                    doc.LoadXml(fmt);
                    var ns = new XmlNamespaceManager(doc.NameTable);
                    ns.AddNamespace("soap", "http://schemas.xmlsoap.org/soap/envelope/");
                    ns.AddNamespace("ns", "http://ACORD.org/Standards/Life/2");
                    return (doc, ns);
                }

                // ============================================================
                // PARSE InquiryFundValues
                // ============================================================
                string bcash = "", bcsv = "", MCV = "", SCharge = "", CSurrenderValue = "";

                var (docFV, nsFV) = ParseXml(responseStateFV);
                XmlNodeList? nodesFV = docFV.SelectNodes("//ns:InquiryFundValuesData", nsFV);
                if (nodesFV != null)
                {
                    foreach (XmlNode node in nodesFV)
                    {
                        MCV = node.SelectSingleNode("ns:MirDvMcvAcumAmt", nsFV)?.InnerText ?? "";
                        SCharge = node.SelectSingleNode("ns:MirDvSurrChrgAnt", nsFV)?.InnerText ?? "";
                        CSurrenderValue = node.SelectSingleNode("ns:MirDvPolCsvAmt", nsFV)?.InnerText ?? "";
                        bcash = node.SelectSingleNode("ns:MirDvPolBaseCvAnt", nsFV)?.InnerText ?? "";
                        bcsv = node.SelectSingleNode("ns:MirDvPolCsvAmt", nsFV)?.InnerText ?? "";
                    }
                }

                // ============================================================
                // PARSE InquirySummary
                // ============================================================
                string PSuspense = "", MSuspense = "", MLoanAmountAvailable = "";

                var (docSMR, nsSMR) = ParseXml(responseStateSMR);
                XmlNodeList? nodesSMR = docSMR.SelectNodes("//ns:InquirySummaryData", nsSMR);
                if (nodesSMR != null)
                {
                    foreach (XmlNode node in nodesSMR)
                    {
                        PSuspense = node.SelectSingleNode("ns:MirCommonFields/ns:MirPolPremSuspAmt", nsSMR)?.InnerText ?? "";
                        MSuspense = node.SelectSingleNode("ns:MirCommonFields/ns:MirPolMiscSuspAmt", nsSMR)?.InnerText ?? "";
                        MLoanAmountAvailable = node.SelectSingleNode("ns:MirCommonFields/ns:MirDvMaxLoanAmt", nsSMR)?.InnerText ?? "";
                    }
                }

                // ============================================================
                // PARSE InquiryPolicyValues
                // ============================================================
                string PaidupAdditionsCaseValuev = "", DividendVCVonDepositv = "";
                string DividendVCVonDepositInterestv = "", TerminalBonusforSurrenderv = "";
                string Totalbonusv = "", UnearnedPremiumv = "", ReturnofPremiumAmountv = "";
                string CashValueofAccumulatedRevisionaryv = "", OutstandingDisbursementsv = "";
                string LoanAmountv = "", LoanInterestPaidCapitalizedYTDv = "";
                string APLAmountv = "", APLInterestPaidCapitalizedYTDv = "";

                var (docPV, nsPV) = ParseXml(responseStatePV);
                XmlNodeList? nodesPV = docPV.SelectNodes("//ns:InquiryPolicyValuesData", nsPV);
                if (nodesPV != null)
                {
                    foreach (XmlNode node in nodesPV)
                    {
                        PaidupAdditionsCaseValuev = node.SelectSingleNode("ns:MirValupolFields/ns:MirDvValuPuaAmt", nsPV)?.InnerText ?? "";
                        DividendVCVonDepositv = node.SelectSingleNode("ns:MirValupolFields/ns:MirPolDodAcumAmt", nsPV)?.InnerText ?? "";
                        DividendVCVonDepositInterestv = node.SelectSingleNode("ns:MirValupolFields/ns:MirDodCrntIntAmt", nsPV)?.InnerText ?? "";
                        TerminalBonusforSurrenderv = node.SelectSingleNode("ns:MirValupolFields/ns:MirDvPolSurrAmt", nsPV)?.InnerText ?? "";
                        Totalbonusv = node.SelectSingleNode("ns:MirValupolFields/ns:MirDvPolBonCshAmt", nsPV)?.InnerText ?? "";
                        UnearnedPremiumv = node.SelectSingleNode("ns:MirValupolFields/ns:MirDvPremRfndAmt", nsPV)?.InnerText ?? "";
                        ReturnofPremiumAmountv = node.SelectSingleNode("ns:MirValupolFields/ns:MirDvRopAmt", nsPV)?.InnerText ?? "";
                        CashValueofAccumulatedRevisionaryv = node.SelectSingleNode("ns:MirValupolFields/ns:MirCvRbAcumAmt", nsPV)?.InnerText ?? "";
                        OutstandingDisbursementsv = node.SelectSingleNode("ns:MirValupolFields/ns:MirPolOsDisbAmt", nsPV)?.InnerText ?? "";
                        LoanAmountv = node.SelectSingleNode("ns:MirValupolFields/ns:MirDvLoanAmt", nsPV)?.InnerText ?? "";
                        LoanInterestPaidCapitalizedYTDv = node.SelectSingleNode("ns:MirValupolFields/ns:MirDvLoanIntYtdAmt", nsPV)?.InnerText ?? "";
                        APLAmountv = node.SelectSingleNode("ns:MirValupolFields/ns:MirDvAplLoanAmt", nsPV)?.InnerText ?? "";
                        APLInterestPaidCapitalizedYTDv = node.SelectSingleNode("ns:MirValupolFields/ns:MirDvAplIntYtdAmt", nsPV)?.InnerText ?? "";
                    }
                }

                // ============================================================
                // PARSE FundInquiryAccumulationUnits
                // ============================================================
                var fundInfoList = new List<FundInformation>();

                var (docFA, nsFA) = ParseXml(responseStateFA);
                XmlNodeList? nodesFA = docFA.SelectNodes("//ns:FundInquiryAccumulationUnitsData", nsFA);
                if (nodesFA != null)
                {
                    foreach (XmlNode node in nodesFA)
                    {
                        XmlNodeList? fundfa = node.SelectNodes("ns:MirFndIdG/ns:MirFndIdT", nsFA);
                        XmlNodeList? unitpricefa = node.SelectNodes("ns:MirFiaAunitPricAmtG/ns:MirFiaAunitPricAntT", nsFA);
                        XmlNodeList? numberofunitfa = node.SelectNodes("ns:MirCfnIntgAunitQtyG/ns:MirCfnIntgAunitQtyT", nsFA);
                        XmlNodeList? persen = node.SelectNodes("ns:MirFndPercentageG/ns:MirFndPercentageT", nsFA);

                        if (fundfa == null || unitpricefa == null) continue;

                        int count = Math.Min(fundfa.Count, unitpricefa.Count);
                        for (int i = 0; i < count; i++)
                        {
                            string fundCode = fundfa[i]?.InnerText ?? "";
                            if (fundCode == "*") continue;

                            fundInfoList.Add(new FundInformation
                            {
                                Fund = fundCode,
                                UnitPrice = ParseDecimal(unitpricefa[i]?.InnerText),
                                ApproximateNumberofUnits = ParseDecimal(numberofunitfa?[i]?.InnerText),
                                BaseCashValue = ParseDecimal(bcash),
                                CashSurrenderValue = ParseDecimal(bcsv),
                                FundPercentage = ParseDecimal(persen?[i]?.InnerText)
                            });
                        }
                    }
                }

                // ============================================================
                // PARSE FundInquiryActivity
                // ============================================================
                var fundActivityList = new List<FundActivityInformation>();

                var (docFVL, nsFVL) = ParseXml(responseStateFVL);
                XmlNodeList? nodesFVL = docFVL.SelectNodes("//ns:FundInquiryActivityData", nsFVL);
                if (nodesFVL != null)
                {
                    foreach (XmlNode node in nodesFVL)
                    {
                        XmlNodeList? actefdatefvl = node.SelectNodes("ns:MirCiaEffDtG/ns:MirCiaEffDtT", nsFVL);
                        XmlNodeList? seqnumberfvl = node.SelectNodes("ns:MirCiaSeqNumG/ns:MirCiaSeqNumT", nsFVL);
                        XmlNodeList? actvtypfvl = node.SelectNodes("ns:MirCiaTypCdG/ns:MirCiaTypCdT", nsFVL);
                        XmlNodeList? topprmfvl = node.SelectNodes("ns:MirCiaCliTrxnAmtG/ns:MirCiaCliTrxnAmtT", nsFVL);
                        XmlNodeList? netamtfvl = node.SelectNodes("ns:MirCiaFndTrxnAmtG/ns:MirCiaFndTrxnAmtT", nsFVL);
                        XmlNodeList? tranchrgfvl = node.SelectNodes("ns:MirCiaLoadAmtG/ns:MirCiaLoadAmtT", nsFVL);

                        if (actefdatefvl == null || seqnumberfvl == null) continue;

                        int count = Math.Min(seqnumberfvl.Count, actefdatefvl.Count);
                        for (int i = 0; i < count; i++)
                        {
                            string effDate = actefdatefvl[i]?.InnerText ?? "";
                            if (string.IsNullOrWhiteSpace(effDate)) continue;

                            fundActivityList.Add(new FundActivityInformation
                            {
                                ActivityEffectiveDate = effDate,
                                SequenceNumber = seqnumberfvl[i]?.InnerText ?? "",
                                ActivityType = actvtypfvl?[i]?.InnerText ?? "",
                                TotalPremiumReceived = topprmfvl?[i]?.InnerText ?? "",
                                NetAmount = netamtfvl?[i]?.InnerText ?? "",
                                TransferCharges = tranchrgfvl?[i]?.InnerText ?? ""
                            });
                        }
                    }
                }

                // ============================================================
                // VALIDASI DATA TIDAK SEMUA KOSONG → 404
                // ============================================================
                bool isAllEmpty = string.IsNullOrWhiteSpace(MCV)
                               && string.IsNullOrWhiteSpace(CSurrenderValue)
                               && string.IsNullOrWhiteSpace(LoanAmountv)
                               && fundInfoList.Count == 0;

                if (isAllEmpty)
                {
                    return NotFound(new ApiErrorResponse
                    {
                        StatusCode = 404,
                        Message = "Data tidak ditemukan",
                        Detail = $"Policy ID '{policyId}' tidak menghasilkan data value information.",
                        Timestamp = DateTime.Now
                    });
                }

                // ============================================================
                // ASSEMBLE RESPONSE
                // ============================================================
                var responseData = new ValueInformationResponse
                {
                    PolicyId = policyId,
                    MCVNetBaseCaseValue = ParseDecimal(MCV),
                    SurrenderCharge = ParseDecimal(SCharge),
                    CashSurrenderValue = ParseDecimal(CSurrenderValue),
                    PaidupAdditionsCaseValue = ParseDecimal(PaidupAdditionsCaseValuev),
                    DividendVCVonDeposit = ParseDecimal(DividendVCVonDepositv),
                    DividendVCVonDepositInterest = ParseDecimal(DividendVCVonDepositInterestv),
                    TerminalBonusforSurrender = ParseDecimal(TerminalBonusforSurrenderv),
                    TotalBonus = ParseDecimal(Totalbonusv),
                    UnearnedPremium = ParseDecimal(UnearnedPremiumv),
                    ReturnofPremiumAmount = ParseDecimal(ReturnofPremiumAmountv),
                    CashValueofAccumulatedRevisionary = ParseDecimal(CashValueofAccumulatedRevisionaryv),
                    OutstandingDisbursements = ParseDecimal(OutstandingDisbursementsv),
                    LoanAmount = ParseDecimal(LoanAmountv),
                    LoanInterestPaidCapitalizedYTD = ParseDecimal(LoanInterestPaidCapitalizedYTDv),
                    APLAmount = ParseDecimal(APLAmountv),
                    APLInterestPaidCapitalizedYTD = ParseDecimal(APLInterestPaidCapitalizedYTDv),
                    PremiumSuspense = ParseDecimal(PSuspense),
                    MiscellaneousSuspense = ParseDecimal(MSuspense),
                    MaximumLoanAmountAvailable = ParseDecimal(MLoanAmountAvailable),
                    FundInformation = fundInfoList.Count > 0 ? fundInfoList : null,
                    FundInquiryActivity = fundActivityList.Count > 0 ? fundActivityList : null
                };

                return Ok(new ApiSuccessResponse<ValueInformationResponse>
                {
                    Success = true,
                    Message = "Data berhasil diambil.",
                    Data = responseData,
                    Timestamp = DateTime.Now
                });
            }
            catch (XmlException xmlEx)
            {
                return StatusCode(500, new ApiErrorResponse
                {
                    StatusCode = 500,
                    Message = "Parse Error",
                    Detail = $"Gagal memproses XML: {xmlEx.Message}",
                    Timestamp = DateTime.Now
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new ApiErrorResponse
                {
                    StatusCode = 500,
                    Message = "Internal Server Error",
                    Detail = ex.Message,
                    Timestamp = DateTime.Now
                });
            }
        }

        // ============================================================
        // BUILD EMPTY RESPONSE — data tidak ditemukan tetap 200
        // ============================================================
        private static ApiSuccessResponse<ValueInformationResponse> BuildEmptySuccessResponse(
            string policyId) =>
            new ApiSuccessResponse<ValueInformationResponse>
            {
                Success = true,
                Message = "Data tidak ditemukan.",
                Timestamp = DateTime.Now,
                Data = new ValueInformationResponse
                {
                    PolicyId = policyId,
                    MCVNetBaseCaseValue = 0,
                    SurrenderCharge = 0,
                    CashSurrenderValue = 0,
                    PaidupAdditionsCaseValue = 0,
                    DividendVCVonDeposit = 0,
                    DividendVCVonDepositInterest = 0,
                    TerminalBonusforSurrender = 0,
                    TotalBonus = 0,
                    UnearnedPremium = 0,
                    ReturnofPremiumAmount = 0,
                    CashValueofAccumulatedRevisionary = 0,
                    OutstandingDisbursements = 0,
                    LoanAmount = 0,
                    LoanInterestPaidCapitalizedYTD = 0,
                    APLAmount = 0,
                    APLInterestPaidCapitalizedYTD = 0,
                    PremiumSuspense = 0,
                    MiscellaneousSuspense = 0,
                    MaximumLoanAmountAvailable = 0,
                    FundInformation = new List<FundInformation>(),
                    FundInquiryActivity = new List<FundActivityInformation>()
                }
            };

        // ============================================================
        // HELPERS
        // ============================================================
        private static decimal ParseDecimal(string? raw) =>
            decimal.TryParse(raw, NumberStyles.Any,
                CultureInfo.InvariantCulture, out var v) ? v : 0;
    }
}
