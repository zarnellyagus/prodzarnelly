﻿using Microsoft.AspNetCore.Mvc;
using Salesforce_API.Service;
using SalesForceAPI.Models;

using System.Globalization;
using System.Xml;
using System.Xml.Linq;

namespace SalesForceAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BenefitInformationController : ControllerBase
    {
        private readonly Requestsoap _requestsoap;

        public BenefitInformationController(Requestsoap requestsoap)
        {
            _requestsoap = requestsoap;
        }

        [HttpPost]
        [ProducesResponseType(typeof(BenefitInformationResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<BenefitInformationResponse>> SendSoapRequestAsync(
            [FromBody] BenefitInformationRequest request)
        {
            // ============================================================
            // VALIDASI REQUEST
            // ============================================================
            if (request == null || string.IsNullOrWhiteSpace(request.PolicyID))
                return BadRequest(new ErrorResponse
                {
                    StatusCode = 400,
                    Message = "Bad Request",
                    Detail = "PolicyID tidak boleh kosong.",
                    Timestamp = DateTime.Now
                });

            string policyId = request.PolicyID.Trim();
            string datenow = DateTime.Today
                                .ToString("ddMMMyyyy", CultureInfo.InvariantCulture)
                                .ToUpper();
            string url = "http://10.154.5.45:8093/TXLife/services/TXLife";

            XNamespace soapNs = "http://schemas.xmlsoap.org/soap/envelope/";
            XNamespace webNs = "http://schema/webservices.elink.solcorp.com";
            XNamespace txNs = "http://ACORD.org/Standards/Life/2";
            XNamespace xsiNs = "http://www.w3.org/2001/XMLSchema-instance";
            XNamespace xsdNs = "http://www.w3.org/2001/XMLSchema";

            try
            {
                // ============================================================
                // BUILD SOAP REQUEST — CallCentreInquiry
                // ============================================================
                var xml = new XElement(soapNs + "Envelope",
                    new XAttribute(XNamespace.Xmlns + "soapenv", soapNs),
                    new XAttribute(XNamespace.Xmlns + "web", webNs),
                    new XElement(soapNs + "Header"),
                    new XElement(soapNs + "Body",
                        new XElement(txNs + "TXLife",
                            new XAttribute(XNamespace.Xmlns + "xsi", xsiNs),
                            new XAttribute(XNamespace.Xmlns + "xsd", xsdNs),
                            new XAttribute(xsiNs + "schemaLocation",
                                "http://ACORD.org/Standards/Life/2 ../xsd/TXLife2.9.00.xsd"),
                            new XElement(txNs + "UserAuthRequest",
                                new XElement(txNs + "UserLoginName", "f180w"),
                                new XElement(txNs + "UserPswd",
                                    new XElement(txNs + "CryptType", "NONE"),
                                    new XElement(txNs + "Pswd", "f180w")),
                                new XElement(txNs + "UserCoId", "CP")),
                            new XElement(txNs + "TXLifeRequest",
                                new XElement(txNs + "TransRefGUID", ""),
                                new XElement(txNs + "TransType",
                                    new XAttribute("tc", "CallCentreInquiry"), ""),
                                new XElement(txNs + "TransExeDate", datenow),
                                new XElement(txNs + "TransExeTime",
                                    DateTime.Now.ToString("HH:mm:ss")),
                                new XElement(txNs + "OLiFE",
                                    new XElement(txNs + "CallCentreInquiryData",
                                        new XElement(txNs + "MirPolId",
                                            new XElement(txNs + "MirPolIdBase", policyId),
                                            new XElement(txNs + "MirPolIdSfx", "")),
                                        new XElement(txNs + "MirCvgNum", ""),
                                        new XElement(txNs + "MirDvEffDt", datenow)))))));

                // ============================================================
                // KIRIM SOAP REQUEST
                // ============================================================
                string responseState = await _requestsoap.PostSOAPRequestAsync(
                    url, xml.ToString());

                // ============================================================
                // SOAP TIDAK MERESPONS → blank data
                // ============================================================
                if (string.IsNullOrWhiteSpace(responseState))
                    return Ok(BuildEmptyResponse());

                // ============================================================
                // PARSE XML
                // ============================================================
                string formattedXml = XDocument.Parse(responseState).ToString();
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(formattedXml);

                XmlNamespaceManager nsMgr = new XmlNamespaceManager(xmlDoc.NameTable);
                nsMgr.AddNamespace("soap", "http://schemas.xmlsoap.org/soap/envelope/");
                nsMgr.AddNamespace("ns", "http://ACORD.org/Standards/Life/2");

                // ============================================================
                // CEK SOAP FAULT → blank data
                // ============================================================
                XmlNode? faultNode = xmlDoc.SelectSingleNode("//soap:Fault", nsMgr);
                if (faultNode != null)
                    return Ok(BuildEmptyResponse());

                // ============================================================
                // CEK RESULT CODE
                // ============================================================
                XmlNode? resultNode = xmlDoc.SelectSingleNode(
                    "//ns:TXLifeResponse/ns:TransResult", nsMgr);
                string? resultCode = resultNode
                    ?.SelectSingleNode("ns:ResultCode", nsMgr)?.InnerText;

                if (!string.IsNullOrWhiteSpace(resultCode) && resultCode != "1")
                    return Ok(BuildEmptyResponse());

                // ============================================================
                // CEK NODE DATA UTAMA → blank data jika tidak ada
                // ============================================================
                XmlNodeList? callCentreNodes = xmlDoc.SelectNodes(
                    "//ns:CallCentreInquiryData", nsMgr);

                if (callCentreNodes == null || callCentreNodes.Count == 0)
                    return Ok(BuildEmptyResponse());

                // ============================================================
                // INISIALISASI LIST
                // ============================================================
                var coverageList = new List<CoverageBenefitInformation>();
                var lifeBenefitList = new List<LifeBenefitInformation>();
                var disabilityList = new List<DisabilityIncomeBenefitPremiumInformation>();

                // ============================================================
                // LOOP NODE
                // ============================================================
                foreach (XmlNode node in callCentreNodes)
                {
                    // ── COVERAGE DETAIL ─────────────────────────────────────
                    XmlNodeList? covnum = node.SelectNodes("ns:MirCommonFields/ns:MirCvgNumG/ns:MirCvgNumT", nsMgr);
                    XmlNodeList? tplan = node.SelectNodes("ns:MirCovdtlFields/ns:MirPlanIdG/ns:MirPlanIdT", nsMgr);
                    XmlNodeList? famnt = node.SelectNodes("ns:MirCovdtlFields/ns:MirCvgFaceAmtG/ns:MirCvgFaceAmtT", nsMgr);
                    XmlNodeList? issdate = node.SelectNodes("ns:MirCovdtlFields/ns:MirCvgIssEffDtG/ns:MirCvgIssEffDtT", nsMgr);
                    XmlNodeList? insname = node.SelectNodes("ns:MirCovdtlFields/ns:MirOvInsrdCliNmG/ns:MirOvInsrdCliNmT", nsMgr);
                    XmlNodeList? ratage = node.SelectNodes("ns:MirCovdtlFields/ns:MirCvgRtAgeG/ns:MirCvgRtAgeT", nsMgr);
                    XmlNodeList? covsts = node.SelectNodes("ns:MirCovdtlFields/ns:MirCvgCstatCdG/ns:MirCvgCstatCdT", nsMgr);
                    XmlNodeList? covmats = node.SelectNodes("ns:MirCovdtlFields/ns:MirCvgMatXpryDtG/ns:MirCvgMatXpryDtT", nsMgr);
                    XmlNodeList? sx = node.SelectNodes("ns:MirCovdtlFields/ns:MirCvgSexCdG/ns:MirCvgSexCdT", nsMgr);

                    // ── LIFE BENEFIT ─────────────────────────────────────────
                    XmlNodeList? accdbf = node.SelectNodes("ns:MirPremcovFields/ns:MirCvgAdPremAntG/ns:MirCvgAdPremAntT", nsMgr);
                    XmlNodeList? adbrt = node.SelectNodes("ns:MirPremcovFields/ns:MirCvgAdMultFctG/ns:MirCvgAdMultFctT", nsMgr);
                    XmlNodeList? wpremium = node.SelectNodes("ns:MirPremcovFields/ns:MirCvgWpPremAmtG/ns:MirCvgWpPremAntT", nsMgr);
                    XmlNodeList? wmulti = node.SelectNodes("ns:MirPremcovFields/ns:MirCvgWpMultFctG/ns:MirCvgWpMultFctT", nsMgr);

                    // ── DISABILITY INCOME BENEFIT ─────────────────────────────
                    XmlNodeList? liftmacc = node.SelectNodes("ns:MirPremcovFields/ns:MirCvgLtaPremAntG/ns:MirCvgLtaPremAntT", nsMgr);
                    XmlNodeList? lifetmbnf = node.SelectNodes("ns:MirPremcovFields/ns:MirCvgLtbPremAntG/ns:MirCvgLtbPremAntT", nsMgr);
                    XmlNodeList? pard = node.SelectNodes("ns:MirPremcovFields/ns:MirPdisabPremAntG/ns:MirPdisabPremAntT", nsMgr);
                    XmlNodeList? costlvad = node.SelectNodes("ns:MirPremcovFields/ns:MirCvgColaPremAntG/ns:MirCvgColaPremAntT", nsMgr);
                    XmlNodeList? ownocp = node.SelectNodes("ns:MirPremcovFields/ns:MirOwnOccpPremAntG/ns:MirOwnOccpPremAntT", nsMgr);
                    XmlNodeList? redela = node.SelectNodes("ns:MirPremcovFields/ns:MirRedcEpPremAntG/ns:MirRedcEpPremAntT", nsMgr);

                    if (covnum == null || covnum.Count == 0) continue;

                    // ── MAP COVERAGE BENEFIT ─────────────────────────────────
                    int countCov = Math.Min(covnum.Count,
                        Math.Min(tplan?.Count ?? 0, famnt?.Count ?? 0));

                    for (int i = 0; i < countCov; i++)
                    {
                        string covCode = covnum[i]?.InnerText ?? "";
                        if (string.IsNullOrWhiteSpace(covCode)) continue;

                        coverageList.Add(new CoverageBenefitInformation
                        {
                            CoverageNumber = covCode,
                            TypeOfPlan = tplan?[i]?.InnerText ?? "",
                            FaceAmount = famnt?[i]?.InnerText ?? "",
                            IssueDate = issdate?[i]?.InnerText ?? "",
                            InsuredsName = insname?[i]?.InnerText ?? "",
                            RateAge = ratage?[i]?.InnerText ?? "",
                            CoverageStatus = covsts?[i]?.InnerText ?? "",
                            CoverageMaturity = covmats?[i]?.InnerText ?? "",
                            Sex = sx?[i]?.InnerText ?? ""
                        });
                    }

                    // ── MAP LIFE BENEFIT ─────────────────────────────────────
                    int countLife = Math.Min(covnum.Count, accdbf?.Count ?? 0);

                    for (int i = 0; i < countLife; i++)
                    {
                        string covCode = covnum[i]?.InnerText ?? "";
                        if (string.IsNullOrWhiteSpace(covCode)) continue;

                        lifeBenefitList.Add(new LifeBenefitInformation
                        {
                            CoverageNumber = covCode,
                            AccidentalDeathBenefitPremium = accdbf?[i]?.InnerText ?? "",
                            ADBRatingMultiplier = adbrt?[i]?.InnerText ?? "",
                            WaiverofPremiumBenefitPremium = wpremium?[i]?.InnerText ?? "",
                            WaiverofPremiumMultiplier = wmulti?[i]?.InnerText ?? ""
                        });
                    }

                    // ── MAP DISABILITY INCOME BENEFIT ────────────────────────
                    int countDis = Math.Min(covnum.Count, liftmacc?.Count ?? 0);

                    for (int i = 0; i < countDis; i++)
                    {
                        string covCode = covnum[i]?.InnerText ?? "";
                        if (string.IsNullOrWhiteSpace(covCode)) continue;

                        disabilityList.Add(new DisabilityIncomeBenefitPremiumInformation
                        {
                            CoverageNumber = covCode,
                            LifetimeAccident = liftmacc?[i]?.InnerText ?? "",
                            LifetimeBenefits = lifetmbnf?[i]?.InnerText ?? "",
                            PartialDisability = pard?[i]?.InnerText ?? "",
                            CostofLivingAdjustments = costlvad?[i]?.InnerText ?? "",
                            OwnOccupationDefinitionofDisability = ownocp?[i]?.InnerText ?? "",
                            ReducedEliminationPeriodinEventofHospitalization = redela?[i]?.InnerText ?? ""
                        });
                    }
                }

                // ============================================================
                // SEMUA LIST KOSONG → blank data
                // ============================================================
                if (coverageList.Count == 0
                    && lifeBenefitList.Count == 0
                    && disabilityList.Count == 0)
                    return Ok(BuildEmptyResponse());

                // ============================================================
                // RETURN 200 — DATA LENGKAP
                // ============================================================
                return Ok(new BenefitInformationResponse
                {
                    CoverageBenefitInformation =
                        coverageList.Count > 0 ? coverageList : null,
                    LifeBenefitInformation =
                        lifeBenefitList.Count > 0 ? lifeBenefitList : null,
                    DisabilityIncomeBenefitPremiumInformation =
                        disabilityList.Count > 0 ? disabilityList : null
                });
            }
            catch (TaskCanceledException)
            {
                return StatusCode(StatusCodes.Status408RequestTimeout, new ErrorResponse
                {
                    StatusCode = 408,
                    Message = "Request Timeout",
                    Detail = "Koneksi ke TXLife melebihi batas waktu.",
                    Timestamp = DateTime.Now
                });
            }
            catch (HttpRequestException ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new ErrorResponse
                {
                    StatusCode = 500,
                    Message = "Service Unavailable",
                    Detail = $"Gagal terhubung ke TXLife: {ex.Message}",
                    Timestamp = DateTime.Now
                });
            }
            catch (XmlException ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new ErrorResponse
                {
                    StatusCode = 500,
                    Message = "Parse Error",
                    Detail = $"Response XML tidak valid: {ex.Message}",
                    Timestamp = DateTime.Now
                });
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new ErrorResponse
                {
                    StatusCode = 500,
                    Message = "Internal Server Error",
                    Detail = ex.Message,
                    Timestamp = DateTime.Now
                });
            }
        }

        // ============================================================
        // BUILD EMPTY RESPONSE — semua field blank
        // ============================================================
        private static BenefitInformationResponse BuildEmptyResponse() =>
            new BenefitInformationResponse
            {
                CoverageBenefitInformation = new List<CoverageBenefitInformation>
                {
                    new CoverageBenefitInformation
                    {
                        CoverageNumber   = "",
                        TypeOfPlan       = "",
                        FaceAmount       = "",
                        IssueDate        = "",
                        InsuredsName     = "",
                        RateAge          = "",
                        CoverageStatus   = "",
                        CoverageMaturity = "",
                        Sex              = ""
                    }
                },
                LifeBenefitInformation = new List<LifeBenefitInformation>
                {
                    new LifeBenefitInformation
                    {
                        CoverageNumber                = "",
                        AccidentalDeathBenefitPremium = "",
                        ADBRatingMultiplier           = "",
                        WaiverofPremiumBenefitPremium = "",
                        WaiverofPremiumMultiplier     = ""
                    }
                },
                DisabilityIncomeBenefitPremiumInformation =
                    new List<DisabilityIncomeBenefitPremiumInformation>
                {
                    new DisabilityIncomeBenefitPremiumInformation
                    {
                        CoverageNumber                                   = "",
                        LifetimeAccident                                 = "",
                        LifetimeBenefits                                 = "",
                        PartialDisability                                = "",
                        CostofLivingAdjustments                         = "",
                        OwnOccupationDefinitionofDisability              = "",
                        ReducedEliminationPeriodinEventofHospitalization = ""
                    }
                }
            };
    }
}