﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Salesforce_API.Models;
using Salesforce_API.Service;

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Xml;
using System.Xml.Linq;

namespace Salesforce_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AnticipatedEndowmentController : ControllerBase
    {
        private readonly Requestsoap _requestsoap;

        public AnticipatedEndowmentController(Requestsoap requestsoap)
        {
            _requestsoap = requestsoap;
        }

        [HttpPost]
        [ProducesResponseType(typeof(List<AnticipatedEndowmentResponse>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(string), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(string), StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<List<AnticipatedEndowmentResponse>>> SendSoapRequestAsync(
            [FromQuery] string Policyid)
        {
            if (string.IsNullOrWhiteSpace(Policyid))
                return BadRequest("PolicyID tidak boleh kosong.");

            string url = "http://10.154.5.45:8093/TXLife/services/TXLife";

            var soapNs = XNamespace.Get("http://schemas.xmlsoap.org/soap/envelope/");
            var TXLifeNs = XNamespace.Get("http://schema/webservices.elink.solcorp.com");
            var TXNs = XNamespace.Get("http://ACORD.org/Standards/Life/2");
            var xsiNs = XNamespace.Get("http://www.w3.org/2001/XMLSchema-instance");
            var xsdNs = XNamespace.Get("http://www.w3.org/2001/XMLSchema");
            var schemaNs = XNamespace.Get("http://ACORD.org/Standards/Life/2../xsd/TXLife2.9.00.xsd");

            // ✅ Fix: <Header> dan <Body> sebagai siblings, bukan nested
            var xmlendw = new XElement(soapNs + "Envelope",
                new XAttribute(XNamespace.Xmlns + "soapenv", soapNs),
                new XAttribute(XNamespace.Xmlns + "web", TXLifeNs),
                new XElement(soapNs + "Header"),
                new XElement(soapNs + "Body",
                    new XElement(TXNs + "TXLife",
                        new XAttribute(XNamespace.Xmlns + "xsi", xsiNs),
                        new XAttribute(XNamespace.Xmlns + "xsd", xsdNs),
                        new XAttribute(XNamespace.Xmlns + "schemaLocation", schemaNs),
                        new XElement(TXNs + "SignonCompany", "CP"),
                        new XElement(TXNs + "UserAuthRequest",
                            new XElement(TXNs + "UserLoginName", "fi80w"),
                            new XElement(TXNs + "UserPswd",
                                new XElement(TXNs + "CryptType", "NONE"),
                                new XElement(TXNs + "Pswd", "fi80w")),
                            new XElement(TXNs + "UserCold", "CP")),
                        new XElement(TXNs + "TXLifeRequest",
                            new XElement(TXNs + "TransRefGUID", ""),
                            new XElement(TXNs + "TransType",
                                new XAttribute("tc", "InquiryAnticipatedEndowment"), ""),
                            new XElement(TXNs + "TransExeDate", ""),
                            new XElement(TXNs + "TransExeTime", ""),
                            new XElement(TXNs + "OLiFE",
                                new XElement(TXNs + "InquiryAnticipatedEndowmentData",
                                    new XElement(TXNs + "MirCommonFields",
                                        new XElement(TXNs + "MirDvEffDt", ""),
                                        new XElement(TXNs + "MirCvgNum", "01"),
                                        new XElement(TXNs + "MirPolPayoNum", "00001")),
                                    new XElement(TXNs + "MirPolId",
                                        new XElement(TXNs + "MirPolIdBase", Policyid),
                                        new XElement(TXNs + "MirPolIdSfx", ""))
                                    )
                                )
                            )
                        )
                    )
                );

            // ✅ Fix: gunakan 'xmlendw' bukan 'xml'
            string xmlSoap = xmlendw.ToString();

            try
            {
                // ✅ Fix: await + nama variabel konsisten
                string responseStatec = await _requestsoap.PostSOAPRequestAsync(url, xmlSoap);

                if (string.IsNullOrWhiteSpace(responseStatec))
                    return NotFound($"Tidak ada response dari TXLife untuk PolicyID '{Policyid}'.");

                string formattedXml = XDocument.Parse(responseStatec).ToString();

                XmlDocument xmldoc = new XmlDocument();
                xmldoc.LoadXml(formattedXml);

                XmlNamespaceManager msgr = new XmlNamespaceManager(xmldoc.NameTable);
                msgr.AddNamespace("soap", "http://schemas.xmlsoap.org/soap/envelope/");
                msgr.AddNamespace("ns", "http://ACORD.org/Standards/Life/2");

                XmlNodeList? EndowmentNodes = xmldoc.SelectNodes(
                    "//ns:InquiryAnticipatedEndowmentData", msgr);

                if (EndowmentNodes == null || EndowmentNodes.Count == 0)
                    return NotFound(
                        $"Data Anticipated Endowment untuk PolicyID '{Policyid}' tidak ditemukan.");

                var results = new List<AnticipatedEndowmentResponse>();

                foreach (XmlNode node in EndowmentNodes)
                {
                    // ✅ Fix: semua child node pakai prefix ns:
                    string? payoutnumber = node.SelectSingleNode("ns:MirCommonFields/ns:MirPolPayoNum", msgr)?.InnerText;
                    string? nextpayoutdate = node.SelectSingleNode("ns:MirCommonFields/ns:MirPolPayoNxtDt", msgr)?.InnerText;
                    string? lastpayoutdate = node.SelectSingleNode("ns:MirCommonFields/ns:MirCdaEffDt", msgr)?.InnerText;
                    string? lastpayamount = node.SelectSingleNode("ns:MirCommonFields/ns:MirLastPayoAmt", msgr)?.InnerText;
                    string? totpayamount = node.SelectSingleNode("ns:MirCommonFields/ns:MirPolPayoAmt", msgr)?.InnerText;
                    string? issueDate = node.SelectSingleNode("ns:MirCommonFields/ns:MirPolPayoEffDt", msgr)?.InnerText;
                    string? AEfund = node.SelectSingleNode("ns:MirValuotrFields/ns:MirPolAeAmt", msgr)?.InnerText;
                    string? AEFundI = node.SelectSingleNode("ns:MirValuotrFields/ns:MirPolAeIntAmt", msgr)?.InnerText;
                    string? loanbalance = node.SelectSingleNode("ns:MirValulnFields/ns:MirDvLoanRepayAmt", msgr)?.InnerText;
                    string? planName = node.SelectSingleNode("ns:MirCommonFields/ns:MirDvFndDescTxt", msgr)?.InnerText;
                    // ✅ Fix: InnerText bukan InnerT
                    string? lastwithdrawal = node.SelectSingleNode("ns:MirCommonFields/ns:MirLastAeWthdrAmt", msgr)?.InnerText;

                    // ✅ Fix: PayoutDate diambil sebagai list dari SelectNodes
                    XmlNodeList? payoutDateNodes = node.SelectNodes(
                        "ns:MirDvXpctPayoDtG/ns:MirDvXpctPayoDtT", msgr);

                    // ✅ Fix: PayoutMethod dari SelectNodes
                    XmlNodeList? paymthdNodes = node.SelectNodes(
                        "ns:MirCdiPayoMthdCdG/ns:MirCdiPayoMthdCdT", msgr);

                    // ============================================
                    // Map ke ContractualPayoutInformation (model)
                    // ============================================
                    var contractualPayout = new ContractualPayoutInformation
                    {
                        PolicyID = Policyid,
                        PayoutMethod = paymthdNodes?.Count > 0
                                            ? paymthdNodes[0]!.InnerText : string.Empty,
                        PayoutNumber = int.TryParse(payoutnumber, out var pn) ? pn : 0,
                        NextPayoutDate = ParseDate(nextpayoutdate),
                        LastPayoutDate = ParseDate(lastpayoutdate),
                        LastPayoutAmount = ParseDecimal(lastpayamount),
                        TotalPayoutAmount = ParseDecimal(totpayamount),
                        IssueDate = ParseDate(issueDate)
                    };

                    // ============================================
                    // Map ke List<PayoutDateInformation> (model)
                    // ============================================
                    var payoutDateList = new List<PayoutDateInformation>();
                    if (payoutDateNodes != null)
                    {
                        for (int i = 0; i < payoutDateNodes.Count; i++)
                        {
                            payoutDateList.Add(new PayoutDateInformation
                            {
                                PolicyID = Policyid,
                                PayoutDate = ParseDate(payoutDateNodes[i]!.InnerText),
                                PayoutAmount = ParseDecimal(totpayamount),
                                PayoutStatus = string.Empty,
                                SequenceNumber = i + 1
                            });
                        }
                    }

                    // ============================================
                    // Map ke AEFundInformation (model)
                    // ============================================
                    var aeFundInfo = new AEFundInformation
                    {
                        PolicyID = Policyid,
                        AEFund = AEfund ?? string.Empty,
                        AEFundInterest = AEFundI ?? string.Empty,
                        LastWithdrawalDate = null,
                        LoanBalance = ParseDecimal(loanbalance),
                        PlanName = planName ?? string.Empty,
                        LastWithdrawalAmount = ParseDecimal(lastwithdrawal)
                    };

                    // ============================================
                    // Wrap ke AnticipatedEndowmentResponse
                    // ============================================
                    results.Add(new AnticipatedEndowmentResponse
                    {
                        ContractualPayoutInfo = contractualPayout,
                        PayoutDates = payoutDateList,
                        AEFundInfo = aeFundInfo
                    });
                }

                // ✅ Fix: return setelah semua loop selesai
                return Ok(results);
            }
            catch (HttpRequestException ex)
            {
                return StatusCode(500, $"Gagal terhubung ke TXLife Webservice: {ex.Message}");
            }
            catch (XmlException ex)
            {
                return StatusCode(500, $"Response XML tidak valid: {ex.Message}");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal Server Error: {ex.Message}");
            }
        }

        // =============================================
        // HELPER METHODS
        // =============================================

        private static decimal ParseDecimal(string? value) =>
            decimal.TryParse(value,
                NumberStyles.Any,
                CultureInfo.InvariantCulture,
                out var v) ? v : 0m;

        private static DateTime? ParseDate(string? value)
        {
            if (string.IsNullOrWhiteSpace(value)) return null;
            return DateTime.TryParse(value,
                CultureInfo.InvariantCulture,
                DateTimeStyles.None,
                out var d) ? d : null;
        }
    }
}