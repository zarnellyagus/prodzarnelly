﻿using Microsoft.AspNetCore.Mvc;
using Salesforce_API.Models;
using Salesforce_API.Service;
using System.Globalization;
using System.Xml;
using System.Xml.Linq;

namespace Salesforce_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AnticipatedEndowmentController : ControllerBase
    {
        private readonly Requestsoap _requestsoap;

        public AnticipatedEndowmentController(Requestsoap requestsoap)
        {
            _requestsoap = requestsoap;
        }

        [HttpPost]
        [ProducesResponseType(typeof(AnticipatedEndowmentResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<AnticipatedEndowmentResponse>> SendSoapRequestAsync(
            [FromBody] AnticipatedEndowmentRequest request)
        {
            // ============================================================
            // VALIDASI REQUEST — return ProblemDetails 400
            // ============================================================
            if (!ModelState.IsValid)
                return ValidationProblem(ModelState);

            if (string.IsNullOrWhiteSpace(request.PolicyID))
                return Problem(
                    title: "Bad Request",
                    detail: "PolicyID tidak boleh kosong.",
                    statusCode: StatusCodes.Status400BadRequest);

            string policyId = request.PolicyID.Trim();
            string datenow = DateTime.Today
                                .ToString("ddMMMyyyy", CultureInfo.InvariantCulture)
                                .ToUpper();
            string url = "http://10.154.5.45:8093/TXLife/services/TXLife";

            XNamespace soapNs = "http://schemas.xmlsoap.org/soap/envelope/";
            XNamespace webNs = "http://schema/webservices.elink.solcorp.com";
            XNamespace txNs = "http://ACORD.org/Standards/Life/2";
            XNamespace xsiNs = "http://www.w3.org/2001/XMLSchema-instance";
            XNamespace xsdNs = "http://www.w3.org/2001/XMLSchema";

            try
            {
                // ============================================================
                // BUILD SOAP REQUEST
                // ============================================================
                var xmlEndw = new XElement(soapNs + "Envelope",
                    new XAttribute(XNamespace.Xmlns + "soapenv", soapNs),
                    new XAttribute(XNamespace.Xmlns + "web", webNs),
                    new XElement(soapNs + "Header"),
                    new XElement(soapNs + "Body",
                        new XElement(txNs + "TXLife",
                            new XAttribute(XNamespace.Xmlns + "xsi", xsiNs),
                            new XAttribute(XNamespace.Xmlns + "xsd", xsdNs),
                            new XAttribute(xsiNs + "schemaLocation",
                                "http://ACORD.org/Standards/Life/2 ../xsd/TXLife2.9.00.xsd"),
                            new XElement(txNs + "UserAuthRequest",
                                new XElement(txNs + "UserLoginName", "f180w"),
                                new XElement(txNs + "UserPswd",
                                    new XElement(txNs + "CryptType", "NONE"),
                                    new XElement(txNs + "Pswd", "f180w")),
                                new XElement(txNs + "UserCoId", "CP")),
                            new XElement(txNs + "TXLifeRequest",
                                new XElement(txNs + "TransRefGUID", ""),
                                new XElement(txNs + "TransType",
                                    new XAttribute("tc", "InquiryAnticipatedEndowment"), ""),
                                new XElement(txNs + "TransExeDate", datenow),
                                new XElement(txNs + "TransExeTime",
                                    DateTime.Now.ToString("HH:mm:ss")),
                                new XElement(txNs + "OLiFE",
                                    new XElement(txNs + "InquiryAnticipatedEndowmentData",
                                        new XElement(txNs + "MirDvBusFcnId", ""),
                                        new XElement(txNs + "MirCommonFields",
                                            new XElement(txNs + "MirDvEffDt", datenow),
                                            new XElement(txNs + "MirCvgNum", "01"),
                                            new XElement(txNs + "MirPolPayoNum", "00001")),
                                        new XElement(txNs + "MirPolId",
                                            new XElement(txNs + "MirPolIdBase", policyId),
                                            new XElement(txNs + "MirPolIdSfx", ""))))))));

                string responseState = await _requestsoap.PostSOAPRequestAsync(url, xmlEndw.ToString());

                // ============================================================
                // SOAP TIDAK MERESPONS → return empty 200
                // ============================================================
                if (string.IsNullOrWhiteSpace(responseState))
                    return Ok(BuildEmptyResponse(policyId));

                // ============================================================
                // PARSE XML
                // ============================================================
                string formattedXml = XDocument.Parse(responseState).ToString();
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(formattedXml);

                XmlNamespaceManager nsMgr = new XmlNamespaceManager(xmlDoc.NameTable);
                nsMgr.AddNamespace("soap", "http://schemas.xmlsoap.org/soap/envelope/");
                nsMgr.AddNamespace("ns", "http://ACORD.org/Standards/Life/2");

                // ============================================================
                // CEK SOAP FAULT → 400 ProblemDetails
                // ============================================================
                XmlNode? faultNode = xmlDoc.SelectSingleNode("//soap:Fault", nsMgr);
                if (faultNode != null)
                {
                    string faultMsg = faultNode.SelectSingleNode("faultstring")?.InnerText
                                      ?? "SOAP Fault tidak diketahui.";
                    return Problem(
                        title: "SOAP Fault",
                        detail: faultMsg,
                        statusCode: StatusCodes.Status400BadRequest);
                }

                // ============================================================
                // CEK RESULT CODE → 404 ProblemDetails
                // ============================================================
                XmlNode? resultNode = xmlDoc.SelectSingleNode(
                    "//ns:TXLifeResponse/ns:TransResult", nsMgr);
                string? resultCode = resultNode
                    ?.SelectSingleNode("ns:ResultCode", nsMgr)?.InnerText;
                string? resultDesc = resultNode
                    ?.SelectSingleNode("ns:ResultInfo/ns:ResultInfoDesc", nsMgr)?.InnerText;

                if (!string.IsNullOrWhiteSpace(resultCode) && resultCode != "1")
                {
                    return Problem(
                        title: "Data tidak ditemukan",
                        detail: !string.IsNullOrWhiteSpace(resultDesc)
                                        ? resultDesc
                                        : $"Policy ID '{policyId}' tidak ditemukan.",
                        statusCode: StatusCodes.Status404NotFound);
                }

                // ============================================================
                // CEK NODE DATA UTAMA
                // ============================================================
                XmlNodeList? endowmentNodes = xmlDoc.SelectNodes(
                    "//ns:InquiryAnticipatedEndowmentData", nsMgr);

                if (endowmentNodes == null || endowmentNodes.Count == 0)
                    return Ok(BuildEmptyResponse(policyId));

                XmlNode firstNode = endowmentNodes[0]!;

                // ============================================================
                // MAPPING - ContractualPayoutInformation
                // ============================================================
                string? payoutMethod = firstNode.SelectSingleNode(
                    "ns:MirCdiPayoMthdCdG/ns:MirCdiPayoMthdCdT", nsMgr)?.InnerText;
                string? payoutNumberRaw = firstNode.SelectSingleNode(
                    "ns:MirCommonFields/ns:MirPolPayoNum", nsMgr)?.InnerText;
                string? nextPayoutDate = firstNode.SelectSingleNode(
                    "ns:MirCommonFields/ns:MirPolPayoNxtDt", nsMgr)?.InnerText;
                string? lastPayoutDate = firstNode.SelectSingleNode(
                    "ns:MirCommonFields/ns:MirCdaEffDt", nsMgr)?.InnerText;
                string? lastPayoutAmt = firstNode.SelectSingleNode(
                    "ns:MirCommonFields/ns:MirLastPayoAmt", nsMgr)?.InnerText;
                string? totalPayoutAmt = firstNode.SelectSingleNode(
                    "ns:MirCommonFields/ns:MirPolPayoAmt", nsMgr)?.InnerText;
                string? issueDate = firstNode.SelectSingleNode(
                    "ns:MirCommonFields/ns:MirPolPayoEffDt", nsMgr)?.InnerText;

                var contractualPayout = new ContractualPayoutInformation
                {
                    PolicyID = policyId,
                    PayoutMethod = payoutMethod ?? "",
                    PayoutNumber = ParseInt(payoutNumberRaw),
                    NextPayoutDate = ParseDate(nextPayoutDate),
                    LastPayoutDate = ParseDate(lastPayoutDate),
                    LastPayoutAmount = ParseDecimal(lastPayoutAmt),
                    TotalPayoutAmount = ParseDecimal(totalPayoutAmt),
                    IssueDate = ParseDate(issueDate)
                };

                // ============================================================
                // MAPPING - PayoutDates
                // ============================================================
                var payoutDateList = new List<PayoutDateInformation>();
                int seqNumber = 1;

                foreach (XmlNode node in endowmentNodes)
                {
                    XmlNodeList? payDateNodes = node.SelectNodes(
                        "ns:MirDvXpctPayoDtG/ns:MirDvXpctPayoDtT", nsMgr);

                    if (payDateNodes == null) continue;

                    foreach (XmlNode dtNode in payDateNodes)
                    {
                        string rawDate = dtNode.InnerText;
                        if (string.IsNullOrWhiteSpace(rawDate)) continue;

                        payoutDateList.Add(new PayoutDateInformation
                        {
                            PolicyID = policyId,
                            PayoutDate = ParseDate(rawDate),
                            PayoutAmount = ParseDecimal(totalPayoutAmt),
                            PayoutStatus = "",
                            SequenceNumber = seqNumber++
                        });
                    }
                }

                // ============================================================
                // MAPPING - AEFundInformation
                // ============================================================
                string? aeFund = firstNode.SelectSingleNode(
                    "ns:MirValuotrFields/ns:MirPolAeAmt", nsMgr)?.InnerText;
                string? aeFundInterest = firstNode.SelectSingleNode(
                    "ns:MirValuotrFields/ns:MirPolAeIntAmt", nsMgr)?.InnerText;
                string? loanBalance = firstNode.SelectSingleNode(
                    "ns:MirValulnFields/ns:MirDvLoanRepayAmt", nsMgr)?.InnerText;
                string? planName = firstNode.SelectSingleNode(
                    "ns:MirCommonFields/ns:MirDvFndDescTxt", nsMgr)?.InnerText;
                string? lastWithdrawAmt = firstNode.SelectSingleNode(
                    "ns:MirCommonFields/ns:MirLastAeWthdrAmt", nsMgr)?.InnerText;

                var aeFundInfo = new AEFundInformation
                {
                    PolicyID = policyId,
                    AEFund = aeFund ?? "",
                    AEFundInterest = aeFundInterest ?? "",
                    LastWithdrawalDate = null,
                    LoanBalance = ParseDecimal(loanBalance),
                    PlanName = planName ?? "",
                    LastWithdrawalAmount = ParseDecimal(lastWithdrawAmt)
                };

                // ============================================================
                // ASSEMBLE & RETURN 200
                // ============================================================
                return Ok(new AnticipatedEndowmentResponse
                {
                    ContractualPayoutInfo = contractualPayout,
                    PayoutDates = payoutDateList.Count > 0 ? payoutDateList : null,
                    AEFundInfo = aeFundInfo
                });
            }
            catch (HttpRequestException ex)
            {
                return Problem(
                    title: "Service Unavailable",
                    detail: $"Gagal terhubung ke TXLife: {ex.Message}",
                    statusCode: StatusCodes.Status500InternalServerError);
            }
            catch (XmlException ex)
            {
                return Problem(
                    title: "Parse Error",
                    detail: $"Response XML tidak valid: {ex.Message}",
                    statusCode: StatusCodes.Status500InternalServerError);
            }
            catch (Exception ex)
            {
                return Problem(
                    title: "Internal Server Error",
                    detail: ex.Message,
                    statusCode: StatusCodes.Status500InternalServerError);
            }
        }

        // ============================================================
        // BUILD EMPTY RESPONSE — data tidak ditemukan tetap 200
        // ============================================================
        private static AnticipatedEndowmentResponse BuildEmptyResponse(string policyId) =>
            new AnticipatedEndowmentResponse
            {
                ContractualPayoutInfo = new ContractualPayoutInformation
                {
                    PolicyID = policyId,
                    PayoutMethod = "",
                    PayoutNumber = 0,
                    NextPayoutDate = null,
                    LastPayoutDate = null,
                    LastPayoutAmount = 0,
                    TotalPayoutAmount = 0,
                    IssueDate = null
                },
                PayoutDates = new List<PayoutDateInformation>
                {
                    new PayoutDateInformation
                    {
                        PolicyID       = policyId,
                        PayoutDate     = null,
                        PayoutAmount   = 0,
                        PayoutStatus   = "",
                        SequenceNumber = 0
                    }
                },
                AEFundInfo = new AEFundInformation
                {
                    PolicyID = policyId,
                    AEFund = "",
                    AEFundInterest = "",
                    LastWithdrawalDate = null,
                    LoanBalance = 0,
                    PlanName = "",
                    LastWithdrawalAmount = 0
                }
            };

        // ============================================================
        // HELPERS
        // ============================================================
        private static decimal ParseDecimal(string? raw) =>
            decimal.TryParse(raw, NumberStyles.Any,
                CultureInfo.InvariantCulture, out var v) ? v : 0m;

        private static DateTime? ParseDate(string? raw)
        {
            if (string.IsNullOrWhiteSpace(raw)) return null;
            // Coba format ddMMMyyyy dulu (contoh: 01JAN2024)
            if (DateTime.TryParseExact(raw, "ddMMMyyyy",
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out var d1))
                return d1;
            // Fallback format umum
            if (DateTime.TryParse(raw, CultureInfo.InvariantCulture,
                    DateTimeStyles.None, out var d2))
                return d2;
            return null;
        }

        private static int ParseInt(string? raw) =>
            int.TryParse(raw, out var v) ? v : 0;
    }
}