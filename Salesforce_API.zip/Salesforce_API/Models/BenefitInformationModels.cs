﻿using System.ComponentModel.DataAnnotations;

namespace SalesForceAPI.Models
{
    // ============================================================
    // REQUEST
    // ============================================================
    public class BenefitInformationRequest
    {
        [Required(ErrorMessage = "PolicyID tidak boleh kosong.")]
        public string PolicyID { get; set; } = string.Empty;
    }

    // ============================================================
    // RESPONSE UTAMA
    // ============================================================
    public class BenefitInformationResponse
    {
        public List<CoverageBenefitInformation>? CoverageBenefitInformation { get; set; }
        public List<LifeBenefitInformation>? LifeBenefitInformation { get; set; }
        public List<DisabilityIncomeBenefitPremiumInformation>? DisabilityIncomeBenefitPremiumInformation { get; set; }
    }

    // ============================================================
    // COVERAGE BENEFIT
    // ============================================================
    public class CoverageBenefitInformation
    {
        public string CoverageNumber { get; set; } = string.Empty;
        public string TypeOfPlan { get; set; } = string.Empty;
        public string FaceAmount { get; set; } = string.Empty;
        public string IssueDate { get; set; } = string.Empty;
        public string InsuredsName { get; set; } = string.Empty;
        public string RateAge { get; set; } = string.Empty;
        public string CoverageStatus { get; set; } = string.Empty;
        public string CoverageMaturity { get; set; } = string.Empty;
        public string Sex { get; set; } = string.Empty;
    }

    // ============================================================
    // LIFE BENEFIT
    // ============================================================
    public class LifeBenefitInformation
    {
        public string CoverageNumber { get; set; } = string.Empty;
        public string AccidentalDeathBenefitPremium { get; set; } = string.Empty;
        public string ADBRatingMultiplier { get; set; } = string.Empty;
        public string WaiverofPremiumBenefitPremium { get; set; } = string.Empty;
        public string WaiverofPremiumMultiplier { get; set; } = string.Empty;
    }

    // ============================================================
    // DISABILITY INCOME BENEFIT
    // ============================================================
    public class DisabilityIncomeBenefitPremiumInformation
    {
        public string CoverageNumber { get; set; } = string.Empty;
        public string LifetimeAccident { get; set; } = string.Empty;
        public string LifetimeBenefits { get; set; } = string.Empty;
        public string PartialDisability { get; set; } = string.Empty;
        public string CostofLivingAdjustments { get; set; } = string.Empty;
        public string OwnOccupationDefinitionofDisability { get; set; } = string.Empty;
        public string ReducedEliminationPeriodinEventofHospitalization { get; set; } = string.Empty;
    }

    // ============================================================
    // ERROR RESPONSE
    // ============================================================
    public class ErrorResponse
    {
        public int StatusCode { get; set; }
        public string Message { get; set; } = string.Empty;
        public string? Detail { get; set; }
        public DateTime Timestamp { get; set; } = DateTime.Now;
    }
}