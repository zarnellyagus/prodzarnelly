﻿namespace Salesforce_API.Models
{
    public class ValueInformationRequest
    {
        public string PolicyId { get; set; } = string.Empty;
    }

    public class ValueInformationResponse
    {
        public string PolicyId { get; set; } = string.Empty;

        // InquiryFundValues
        public decimal MCVNetBaseCaseValue { get; set; }
        public decimal SurrenderCharge { get; set; }
        public decimal CashSurrenderValue { get; set; }

        // InquiryPolicyValues
        public decimal PaidupAdditionsCaseValue { get; set; }
        public decimal DividendVCVonDeposit { get; set; }
        public decimal DividendVCVonDepositInterest { get; set; }
        public decimal TerminalBonusforSurrender { get; set; }
        public decimal TotalBonus { get; set; }
        public decimal UnearnedPremium { get; set; }
        public decimal ReturnofPremiumAmount { get; set; }
        public decimal CashValueofAccumulatedRevisionary { get; set; }
        public decimal OutstandingDisbursements { get; set; }
        public decimal LoanAmount { get; set; }
        public decimal LoanInterestPaidCapitalizedYTD { get; set; }
        public decimal APLAmount { get; set; }
        public decimal APLInterestPaidCapitalizedYTD { get; set; }

        // InquirySummary
        public decimal PremiumSuspense { get; set; }
        public decimal MiscellaneousSuspense { get; set; }
        public decimal MaximumLoanAmountAvailable { get; set; }

        // Lists
        public List<FundInformation>? FundInformation { get; set; }
        public List<FundActivityInformation>? FundInquiryActivity { get; set; }
    }

    public class FundInformation
    {
        public string Fund { get; set; } = string.Empty;
        public decimal UnitPrice { get; set; }
        public decimal ApproximateNumberofUnits { get; set; }
        public decimal BaseCashValue { get; set; }
        public decimal CashSurrenderValue { get; set; }
        public decimal FundPercentage { get; set; }
    }

    public class FundActivityInformation
    {
        public string ActivityEffectiveDate { get; set; } = string.Empty;
        public string SequenceNumber { get; set; } = string.Empty;
        public string ActivityType { get; set; } = string.Empty;
        public string TotalPremiumReceived { get; set; } = string.Empty;
        public string NetAmount { get; set; } = string.Empty;
        public string TransferCharges { get; set; } = string.Empty;
    }

    public class ApiSuccessResponse<T>
    {
        public bool Success { get; set; }
        public string Message { get; set; } = string.Empty;
        public T? Data { get; set; }
        public DateTime Timestamp { get; set; }
    }

    public class ApiErrorResponse
    {
        public int StatusCode { get; set; }
        public string Message { get; set; } = string.Empty;
        public string? Detail { get; set; }
        public DateTime Timestamp { get; set; }
    }
}