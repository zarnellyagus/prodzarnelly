﻿using System;
using System.Collections.Generic;
namespace Salesforce_API.Models
{
    // Request Model
    public class AnticipatedEndowmentRequest
    {
        public string PolicyID { get; set; } = string.Empty;
    }
    // Response Model
    public class AnticipatedEndowmentResponse
    {
        public ContractualPayoutInformation? ContractualPayoutInfo { get; set; }
        public List<PayoutDateInformation>? PayoutDates { get; set; }
        public AEFundInformation? AEFundInfo { get; set; }
    }
    // Contractual Payout Information
    public class ContractualPayoutInformation
    {
        public string PolicyID { get; set; } = string.Empty;
        public string PayoutMethod { get; set; } = string.Empty;
        public int PayoutNumber { get; set; }
        public DateTime? NextPayoutDate { get; set; }
        public DateTime? LastPayoutDate { get; set; }
        public decimal LastPayoutAmount { get; set; }
        public decimal TotalPayoutAmount { get; set; }
        public DateTime? IssueDate { get; set; }
    }
    // Payout Date
    public class PayoutDateInformation
    {
        public string PolicyID { get; set; } = string.Empty;
        public DateTime? PayoutDate { get; set; }
        public decimal PayoutAmount { get; set; }
        public string PayoutStatus { get; set; } = string.Empty;
        public int SequenceNumber { get; set; }
    }
    // AE Fund Information
    public class AEFundInformation
    {
        public string PolicyID { get; set; } = string.Empty;
        public string AEFund { get; set; } = string.Empty;
        public string AEFundInterest { get; set; } = string.Empty;
        public DateTime? LastWithdrawalDate { get; set; }
        public decimal LoanBalance { get; set; }
        public string PlanName { get; set; } = string.Empty;
        public decimal LastWithdrawalAmount { get; set; }
    }
}