﻿using System.Text;

namespace Salesforce_API.Service
{
    public class Requestsoap
    {
        private readonly HttpClient _httpClient;

        public Requestsoap(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<string> PostSOAPRequestAsync(string url, string xmlBody)
        {
            var content = new StringContent(xmlBody, Encoding.UTF8, "text/xml");
            content.Headers.Add("SOAPAction", "");

            var response = await _httpClient.PostAsync(url, content);
            response.EnsureSuccessStatusCode();

            return await response.Content.ReadAsStringAsync();
        }
    }
}
