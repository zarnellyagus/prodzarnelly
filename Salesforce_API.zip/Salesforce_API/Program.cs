using Salesforce_API.Service;

var builder = WebApplication.CreateBuilder(args);

// =============================================
// 1. CONTROLLERS & JSON OPTIONS
// =============================================

builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.PropertyNamingPolicy =
            System.Text.Json.JsonNamingPolicy.CamelCase;

        options.JsonSerializerOptions.DefaultIgnoreCondition =
            System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull;
    });

// =============================================
// 2. HTTP CLIENT & REQUESTSOAP SERVICE
// =============================================

builder.Services.AddHttpClient<Requestsoap>(client =>
{
    client.Timeout = TimeSpan.FromSeconds(30);
    client.DefaultRequestHeaders.Add("Accept", "text/xml");
});

builder.Services.AddScoped<Requestsoap>();

// =============================================
// 3. SWAGGER
// =============================================

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
    {
        Title = "SalesforceAPI - TXLife Integration",
        Version = "v1",
        Description = "API integrasi TXLife Webservice (ACORD Standard)"
    });
});

// =============================================
// BUILD APP
// =============================================

var app = builder.Build();

// =============================================
// 4. MIDDLEWARE PIPELINE
// ? Swagger aktif di semua environment
// =============================================

app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/v1/swagger.json", "SalesforceAPI v1");
    
});

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();