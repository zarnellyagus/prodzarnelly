// services/report.service.ts
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface ConsolidatedResponse {
  success: boolean;
  total:   number;
  columns: string[];
  data:    Record<string, any>[];
}

@Injectable({ providedIn: 'root' })
export class ReportService {
  private baseUrl = 'https://localhost:7147/api/report';

  constructor(private http: HttpClient) {}

  getConsolidated(
    startDate: string,
    endDate:   string,
    policyID?: string
  ): Observable<ConsolidatedResponse> {
    let params = new HttpParams()
      .set('startDate', startDate)
      .set('endDate',   endDate);

    if (policyID?.trim())
      params = params.set('policyID', policyID.trim());

    return this.http.get<ConsolidatedResponse>(
      `${this.baseUrl}/consolidated`, { params }
    );
  }
}