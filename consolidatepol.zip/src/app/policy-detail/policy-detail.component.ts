import { Component, OnInit, Input, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import {
  PolicyService,
  PolicyInfo,
  EPolicy,
  PolicySummary
} from '../services/policy.service';

@Component({
  selector: 'app-policy-detail',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule
  ],
  providers: [DatePipe],
  templateUrl: './policy-detail.component.html',
  styleUrls: ['./policy-detail.component.scss']
})
export class PolicyDetailComponent implements OnInit, OnChanges {

  @Input() policyId: string = '';

  policyInfo: PolicyInfo | null = null;
  ePolicies: EPolicy[] = [];
  policySummaries: PolicySummary[] = [];

  // ← nama loading sesuai yang dipakai di HTML
  policyInfoLoading: boolean = false;
  ePolicyLoading: boolean = false;
  policySummaryLoading: boolean = false;

  errorMessage: string = '';
  activeTab: 'info' | 'epolicy' | 'summary' = 'info';

  constructor(
    private policyService: PolicyService,
    private router: Router,
    private datePipe: DatePipe
  ) {}

  ngOnInit(): void {
    if (this.policyId) {
      this.loadAll();
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['policyId'] && !changes['policyId'].firstChange) {
      const newId = changes['policyId'].currentValue;
      if (newId) {
        this.resetState();
        this.loadAll();
      }
    }
  }

  private resetState(): void {
    this.policyInfo = null;
    this.ePolicies = [];
    this.policySummaries = [];
    this.errorMessage = '';
    this.activeTab = 'info';
  }

  private loadAll(): void {
    this.loadPolicyInfo();
    this.loadEPolicy();
    this.loadPolicySummary();
  }

  loadPolicyInfo(): void {
    this.policyInfoLoading = true;
    this.errorMessage = '';

    this.policyService.getPolicyInfo(this.policyId).subscribe({
      next: (info: PolicyInfo) => {
        this.policyInfo = info;
        this.policyInfoLoading = false;
      },
      error: (error) => {
        console.error('Error loadPolicyInfo:', error);
        this.errorMessage = 'Gagal memuat detail policy.';
        this.policyInfoLoading = false;
      }
    });
  }

  loadEPolicy(): void {
    this.ePolicyLoading = true;

    this.policyService.getEPolicy(this.policyId).subscribe({
      next: (data: EPolicy[]) => {
        this.ePolicies = data;
        this.ePolicyLoading = false;
      },
      error: (error) => {
        console.error('Error loadEPolicy:', error);
        this.ePolicies = [];
        this.ePolicyLoading = false;
      }
    });
  }

  loadPolicySummary(): void {
    this.policySummaryLoading = true;

    this.policyService.getPolicySummary(this.policyId).subscribe({
      next: (summaries: PolicySummary[]) => {
        this.policySummaries = summaries;
        this.policySummaryLoading = false;
      },
      error: (error) => {
        console.error('Error loadPolicySummary:', error);
        this.policySummaries = [];
        this.policySummaryLoading = false;
      }
    });
  }

  setTab(tab: 'info' | 'epolicy' | 'summary'): void {
    this.activeTab = tab;
  }

  goBack(): void {
    this.router.navigate(['/consolidate-policy']);
  }

  // ← method untuk akses field PolicyInfo secara safe
  getPolicyInfoValue(field: keyof PolicyInfo): string {
    if (!this.policyInfo) return '-';
    const val = this.policyInfo[field];
    return val != null && val !== '' ? String(val) : '-';
  }

  // ← method untuk field date di PolicyInfo
  getPolicyInfoDateValue(field: keyof PolicyInfo): string {
    if (!this.policyInfo) return '-';
    return this.formatDate(this.policyInfo[field]);
  }

  // ← method untuk akses field EPolicy secara safe
  getEPolicyValue(epolicy: EPolicy, field: keyof EPolicy): string {
    const val = epolicy[field];
    return val != null && val !== '' ? String(val) : '-';
  }

  // ← method untuk field date di EPolicy
  getEPolicyDateValue(epolicy: EPolicy, field: keyof EPolicy): string {
    return this.formatDate(epolicy[field]);
  }

  formatDate(date: any, format: string = 'dd/MM/yyyy'): string {
    if (!date) return '-';
    return this.datePipe.transform(date, format) || '-';
  }

  formatCurrency(value: number | null | undefined): string {
    if (value == null) return '-';
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(value);
  }
}