// report/report.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ReportService } from '../services/report.service';
import { ExcelExportService } from '../services/excel-export.service';

@Component({
  selector: 'app-report',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './report.component.html',
  styleUrls:  ['./report.component.scss']
})
export class ReportComponent {
  startDate = '';
  endDate   = '';
  policyID  = '';
  appNo      = '';
  settleDate = '';

  isLoading  = false;
  isExporting = false;
  errorMsg   = '';
  successMsg = '';
  totalRows  = 0;

  constructor(
    private reportSvc: ReportService,
    private excelSvc:  ExcelExportService
  ) {}

  onRun(): void {
  this.errorMsg   = '';
  this.successMsg = '';

  if (!this.startDate || !this.endDate) {
    this.errorMsg = 'Start Date dan End Date wajib diisi.';
    return;
  }

    this.isLoading = true;

   this.isLoading = true;

  this.reportSvc.getConsolidated({
    startDate:  this.startDate,
    endDate:    this.endDate,
    policyID:   this.policyID   || undefined,
    appNo:      this.appNo      || undefined,
    settleDate: this.settleDate || undefined
  }).subscribe({
    next: async (res) => {
      this.isLoading = false;

      if (!res.success || res.total === 0) {
        this.errorMsg = 'Tidak ada data ditemukan.';
        return;
      }

      this.totalRows   = res.total;
      this.isExporting = true;

      try {
        await this.excelSvc.exportConsolidated(
          res.columns, res.data, 'ConsolidatedReport'
        );
        this.successMsg = `Berhasil export ${res.total} baris data ke Excel.`;
      } catch (e) {
        this.errorMsg = 'Gagal membuat file Excel.';
      } finally {
        this.isExporting = false;
      }
    },
    error: (err: any) => {
      this.isLoading = false;
      this.errorMsg  = err?.error?.message ?? 'Gagal mengambil data dari server.';
    }
  });
}

onReset(): void {
  this.startDate  = '';
  this.endDate    = '';
  this.policyID   = '';
  this.appNo      = '';       // ← reset
  this.settleDate = '';       // ← reset
  this.errorMsg   = '';
  this.successMsg = '';
  this.totalRows  = 0;
}
}